
# FVA presentation plots

## 목적

논문/발표용 figure를 자동 생성합니다.

- FVA pathway heatmap
- FVA pathway dot plot
- observed phenotype heatmap
- interval-level FVA heatmap
- observed phenotype vs FVA correlation bubble plot
- DM_igg_g objective feasibility plot

## 설치

```text
C:\CHO_POC\scripts\06_make_fva_presentation_plots.py
```

## 실행

```bat
cd /d C:\CHO_POC
python scripts\06_make_fva_presentation_plots.py --base C:\CHO_POC --top-n 3
```

pathway별 clone 차이를 더 강조하려면:

```bat
python scripts\06_make_fva_presentation_plots.py --base C:\CHO_POC --top-n 3 --use-zscore
```

## 출력 위치

```text
results\figures\presentation\
results\tables\presentation\
```

## 추천 메인 figure

```text
01_fva_pathway_flexibility_heatmap.png
02_fva_pathway_flexibility_dotplot.png
03_observed_clone_metrics_heatmap.png
06_DM_igg_g_objective_feasibility.png
```

## 해석 주의

FVA 값은 pathway activity가 아니라 flux variability/flexibility입니다.

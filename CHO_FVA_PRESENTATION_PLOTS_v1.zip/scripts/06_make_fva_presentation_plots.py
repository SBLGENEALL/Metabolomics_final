
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def clean_condition(s):
    return s.astype(str).str.strip().str.replace(r"\.0$", "", regex=True)


def minmax_df(df):
    arr = df.astype(float)
    mn = np.nanmin(arr.values)
    mx = np.nanmax(arr.values)
    if not np.isfinite(mn) or not np.isfinite(mx) or mx == mn:
        return arr * 0 + 0.5
    return (arr - mn) / (mx - mn)


def zscore_by_row(df):
    x = df.astype(float)
    mean = x.mean(axis=1)
    std = x.std(axis=1).replace(0, np.nan)
    return x.sub(mean, axis=0).div(std, axis=0).fillna(0)


def save_heatmap(matrix, out, title, xlabel="", ylabel="", figsize=(8, 5), annotate=True):
    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(matrix.values, aspect="auto")
    ax.set_xticks(range(matrix.shape[1]))
    ax.set_xticklabels(matrix.columns, rotation=45, ha="right")
    ax.set_yticks(range(matrix.shape[0]))
    ax.set_yticklabels(matrix.index)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    cbar = fig.colorbar(im, ax=ax)
    cbar.ax.set_ylabel("Value", rotation=270, labelpad=15)

    if annotate and matrix.shape[0] * matrix.shape[1] <= 120:
        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                val = matrix.iloc[i, j]
                if pd.notna(val):
                    ax.text(j, i, f"{val:.2g}", ha="center", va="center", fontsize=8)

    fig.tight_layout()
    fig.savefig(out, dpi=300)
    plt.close(fig)


def save_dotplot(matrix_raw, matrix_size, out, title, xlabel="", ylabel="", figsize=(8, 5)):
    pathways = list(matrix_raw.index)
    clones = list(matrix_raw.columns)
    fig, ax = plt.subplots(figsize=figsize)
    xs, ys, vals, sizes = [], [], [], []
    for i, pathway in enumerate(pathways):
        for j, clone in enumerate(clones):
            v = matrix_raw.loc[pathway, clone]
            s = matrix_size.loc[pathway, clone]
            if pd.notna(v):
                xs.append(j)
                ys.append(i)
                vals.append(v)
                sizes.append(80 + 520 * max(0, min(1, float(s))))
    sc = ax.scatter(xs, ys, s=sizes, c=vals, alpha=0.85)
    ax.set_xticks(range(len(clones)))
    ax.set_xticklabels(clones, rotation=45, ha="right")
    ax.set_yticks(range(len(pathways)))
    ax.set_yticklabels(pathways)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    cbar = fig.colorbar(sc, ax=ax)
    cbar.ax.set_ylabel("FVA flexibility", rotation=270, labelpad=15)
    ax.grid(True, linewidth=0.3, alpha=0.4)
    fig.tight_layout()
    fig.savefig(out, dpi=300)
    plt.close(fig)


def save_corr_bubble(corr, out, title, figsize=(9, 6)):
    labels_x = list(corr.columns)
    labels_y = list(corr.index)
    fig, ax = plt.subplots(figsize=figsize)
    xs, ys, colors, sizes = [], [], [], []
    for i, ylab in enumerate(labels_y):
        for j, xlab in enumerate(labels_x):
            v = corr.loc[ylab, xlab]
            if pd.notna(v):
                xs.append(j)
                ys.append(i)
                colors.append(v)
                sizes.append(40 + 650 * abs(float(v)))
    sc = ax.scatter(xs, ys, s=sizes, c=colors, vmin=-1, vmax=1, alpha=0.9)
    ax.set_xticks(range(len(labels_x)))
    ax.set_xticklabels(labels_x, rotation=75, ha="right", fontsize=8)
    ax.set_yticks(range(len(labels_y)))
    ax.set_yticklabels(labels_y, fontsize=8)
    ax.set_title(title)
    cbar = fig.colorbar(sc, ax=ax)
    cbar.ax.set_ylabel("Correlation", rotation=270, labelpad=15)
    ax.grid(True, linewidth=0.3, alpha=0.4)
    fig.tight_layout()
    fig.savefig(out, dpi=300)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--top-n", type=int, default=3)
    ap.add_argument("--use-zscore", action="store_true")
    args = ap.parse_args()

    base = Path(args.base).resolve()
    figdir = base / "results" / "figures" / "presentation"
    tabledir = base / "results" / "tables" / "presentation"
    figdir.mkdir(parents=True, exist_ok=True)
    tabledir.mkdir(parents=True, exist_ok=True)

    clone_path = base / "results" / "tables" / "clone_decision_summary.csv"
    fva_clone_path = base / "results" / "tables" / "targeted_product_fva" / "targeted_product_fva_clone_summary_FILTERED.csv"
    fva_interval_path = base / "results" / "tables" / "targeted_product_fva" / "targeted_product_fva_pathway_summary_FILTERED.csv"
    sol_path = base / "results" / "tables" / "targeted_product_fva" / "targeted_product_fva_solution_summary.csv"

    if not fva_clone_path.exists():
        raise FileNotFoundError(fva_clone_path)
    if not clone_path.exists():
        raise FileNotFoundError(clone_path)

    clone = pd.read_csv(clone_path)
    clone["condition"] = clean_condition(clone["condition"])
    if "rank" in clone.columns:
        clone = clone.sort_values("rank")
    elif "decision_score_0to1" in clone.columns:
        clone = clone.sort_values("decision_score_0to1", ascending=False)
    top_conditions = clone["condition"].head(args.top_n).tolist()

    fva = pd.read_csv(fva_clone_path)
    fva["condition"] = clean_condition(fva["condition"])
    fva = fva[fva["condition"].isin(top_conditions)].copy()

    value_col = "mean_filtered_fva_sum_range"
    matrix = fva.pivot_table(index="pathway", columns="condition", values=value_col, aggfunc="mean")
    matrix = matrix.reindex(columns=top_conditions)
    matrix = matrix.sort_values(by=top_conditions[0], ascending=False)
    matrix.to_csv(tabledir / "figure_matrix_fva_pathway_by_clone.csv", encoding="utf-8-sig")

    heat_value = zscore_by_row(matrix) if args.use_zscore else matrix
    heat_value.to_csv(tabledir / "figure_matrix_fva_pathway_by_clone_plotted.csv", encoding="utf-8-sig")

    save_heatmap(
        heat_value,
        figdir / "01_fva_pathway_flexibility_heatmap.png",
        "IgG-objective constrained pathway flux variability",
        xlabel="Clone",
        ylabel="Pathway",
        figsize=(7.5, 5.2),
        annotate=True,
    )

    save_dotplot(
        matrix,
        minmax_df(matrix),
        figdir / "02_fva_pathway_flexibility_dotplot.png",
        "Filtered FVA pathway flexibility dot plot",
        xlabel="Clone",
        ylabel="Pathway",
        figsize=(7.5, 5.2),
    )

    obs_cols = [
        "final_titer_g_L", "mean_qP_pg_cell_day", "final_viability_pct",
        "mean_rate_Glucose", "mean_rate_Lactate", "mean_rate_Glutamine", "mean_rate_Ammonia",
    ]
    obs = clone[clone["condition"].isin(top_conditions)].set_index("condition")
    available_obs = [c for c in obs_cols if c in obs.columns]
    if available_obs:
        obs_mat = obs[available_obs].apply(pd.to_numeric, errors="coerce").T
        obs_mat = obs_mat.reindex(columns=top_conditions)
        obs_mat.to_csv(tabledir / "figure_matrix_observed_metrics_raw.csv", encoding="utf-8-sig")
        obs_z = zscore_by_row(obs_mat)
        obs_z.to_csv(tabledir / "figure_matrix_observed_metrics_zscore.csv", encoding="utf-8-sig")
        save_heatmap(
            obs_z,
            figdir / "03_observed_clone_metrics_heatmap.png",
            "Observed productivity and exchange phenotype",
            xlabel="Clone",
            ylabel="Metric",
            figsize=(7.5, 4.8),
            annotate=True,
        )

    if fva_interval_path.exists():
        fi = pd.read_csv(fva_interval_path)
        fi["condition"] = clean_condition(fi["condition"])
        fi = fi[fi["condition"].isin(top_conditions)].copy()
        if not fi.empty:
            fi["clone_interval"] = fi["condition"] + "_" + fi["interval"].astype(str)
            interval_mat = fi.pivot_table(index="pathway", columns="clone_interval", values="filtered_fva_sum_range", aggfunc="mean")
            ordered_cols = []
            for c in top_conditions:
                ordered_cols.extend([x for x in interval_mat.columns if str(x).startswith(c + "_")])
            interval_mat = interval_mat.reindex(columns=ordered_cols)
            interval_mat = interval_mat.reindex(index=matrix.index)
            interval_mat.to_csv(tabledir / "figure_matrix_fva_pathway_by_interval.csv", encoding="utf-8-sig")
            save_heatmap(
                zscore_by_row(interval_mat),
                figdir / "04_fva_pathway_interval_heatmap.png",
                "Interval-level IgG-objective FVA flexibility",
                xlabel="Clone interval",
                ylabel="Pathway",
                figsize=(12, 5.2),
                annotate=False,
            )

    if available_obs and matrix.shape[1] >= 3:
        obs_by_clone = obs[available_obs].apply(pd.to_numeric, errors="coerce")
        fva_by_clone = matrix.T
        merged = obs_by_clone.join(fva_by_clone, how="inner")
        if merged.shape[0] >= 3:
            corr = pd.DataFrame(index=matrix.index, columns=available_obs, dtype=float)
            for pathway in matrix.index:
                for metric in available_obs:
                    corr.loc[pathway, metric] = merged[pathway].corr(merged[metric])
            corr.to_csv(tabledir / "figure_matrix_observed_vs_fva_correlation.csv", encoding="utf-8-sig")
            save_corr_bubble(
                corr,
                figdir / "05_observed_vs_fva_correlation_bubble.png",
                "Correlation between observed phenotype and FVA flexibility",
                figsize=(9.5, 5.5),
            )

    if sol_path.exists():
        sol = pd.read_csv(sol_path)
        sol["condition"] = clean_condition(sol["condition"])
        sol = sol[sol["condition"].isin(top_conditions)].copy()
        sol.to_csv(tabledir / "objective_feasibility_summary.csv", index=False, encoding="utf-8-sig")
        if "objective_value" in sol.columns and "interval" in sol.columns:
            sol["objective_value"] = pd.to_numeric(sol["objective_value"], errors="coerce")
            fig, ax = plt.subplots(figsize=(8, 4.5))
            for cond, sub in sol.groupby("condition"):
                if "day_start" in sub.columns:
                    sub = sub.sort_values("day_start")
                ax.plot(sub["interval"].astype(str), sub["objective_value"], marker="o", label=cond)
            ax.set_title("DM_igg_g objective feasibility across intervals")
            ax.set_xlabel("Interval")
            ax.set_ylabel("DM_igg_g objective value")
            ax.legend()
            fig.tight_layout()
            fig.savefig(figdir / "06_DM_igg_g_objective_feasibility.png", dpi=300)
            plt.close(fig)

    md = []
    md.append("# Presentation figures generated")
    md.append("")
    md.append("Generated figures:")
    md.append("- `01_fva_pathway_flexibility_heatmap.png`")
    md.append("- `02_fva_pathway_flexibility_dotplot.png`")
    md.append("- `03_observed_clone_metrics_heatmap.png`")
    md.append("- `04_fva_pathway_interval_heatmap.png`")
    md.append("- `05_observed_vs_fva_correlation_bubble.png`")
    md.append("- `06_DM_igg_g_objective_feasibility.png`")
    md.append("")
    md.append("Recommended wording:")
    md.append("> Filtered FVA values represent model-inferred flux variability under the DM_igg_g IgG demand objective, not direct intracellular pathway activity.")
    (figdir / "README_PRESENTATION_FIGURES.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    print("[OK] presentation figures saved in:", figdir)
    for p in sorted(figdir.glob("*.png")):
        print(" -", p)


if __name__ == "__main__":
    main()

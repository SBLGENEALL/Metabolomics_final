# CHO Metabolomics + IgG-targeted FVA Final Staged Pipeline

이 최종본은 지금까지의 시행착오를 반영해서 **필수 단계만 1, 2, 3, 4, 5번으로 다시 정리한 버전**입니다.

핵심 목적은 아래입니다.

1. Raw Excel에서 feed-corrected exchange rate 계산
2. Clone ranking 산출
3. iCHO3K 모델에서 IgG objective 확인
4. `DM_igg_g`를 objective로 top clone targeted FVA 수행
5. Bound-driven reaction을 제거한 filtered FVA summary 생성

---

## 0. 새 프로젝트에 필요한 것

새로 실행할 때 필요한 것은 두 가지입니다.

```text
1. 모델 파일
2. Raw data Excel
```

권장 위치:

```text
C:\CHO_POC
├─ model
│  └─ iCHO3K-main\iCHO3K\Model\iCHO3K_cho_prod_generic_unblocked.json
└─ data
   └─ metabolomics
      └─ raw
         └─ CHO_raw_data.xlsx
```

20AA 연습용 파일은 이미 포함되어 있습니다.

```text
data\metabolomics\raw\CHO_raw_data_practice_20AA.xlsx
examples\CHO_raw_data_practice_20AA.xlsx
```

---

## 1. 전체 한 번에 실행

20AA practice data로 전체 실행:

```bat
cd /d C:\CHO_POC

python scripts\00_RUN_ALL.py --base C:\CHO_POC --raw-excel "C:\CHO_POC\data\metabolomics\raw\CHO_raw_data_practice_20AA.xlsx" --volume 50
```

내 raw data로 실행:

```bat
python scripts\00_RUN_ALL.py --base C:\CHO_POC --raw-excel "C:\CHO_POC\data\metabolomics\raw\CHO_raw_data.xlsx" --volume 50
```

---

## 2. 단계별 실행

### Stage 1. Raw Excel → exchange rates

```bat
python scripts\01_prepare_exchange_rates.py --base C:\CHO_POC --raw-excel "C:\CHO_POC\data\metabolomics\raw\CHO_raw_data.xlsx" --volume 50
```

출력:

```text
data\metabolomics\processed\converted_process_data.csv
data\metabolomics\processed\converted_extracellular_metabolomics.csv
data\metabolomics\processed\exchange_rates_feed_corrected.csv
```

확인할 것:

```text
exchange-rate metabolite count
```

20AA 데이터라면 20개 이상이면 좋습니다.  
5개 내외이면 limited metabolite panel이므로 FVA/pathway 해석은 약해집니다.

---

### Stage 2. Clone ranking

```bat
python scripts\02_rank_clones.py --base C:\CHO_POC
```

출력:

```text
results\tables\clone_decision_summary.csv
results\tables\batch\batch_clone_level_summary.csv
```

의미:

```text
titer, qP, viability, feed-corrected glucose/lactate/gln/NH4 burden 기반 ranking
```

이 단계는 FBA가 clone을 새로 발견했다기보다, raw-derived exchange phenotype ranking입니다.

---

### Stage 3. IgG objective 준비

```bat
python scripts\03_prepare_igg_objective.py --base C:\CHO_POC
```

출력:

```text
results\tables\pathway_reaction_sets_core.csv
results\tables\product_objective_candidates_STRICT.csv
results\tables\RECOMMENDED_PRODUCT_OBJECTIVE_STRICT.txt
results\tables\igg_unblock_debug\04_igg_objective_unblock_tests.csv
```

중요 결론:

```text
DM_igg_g = 가장 명확한 IgG demand objective
```

`DM_igg_g`가 measured exchange constraints에서 nonzero이면 다음 단계 FVA를 진행할 수 있습니다.

---

### Stage 4. DM_igg_g targeted product FVA

Top 3 clone 자동 선택:

```bat
python scripts\04_run_igg_product_fva.py --base C:\CHO_POC --top-n 3 --objective DM_igg_g --fraction 0.9 --bound-buffer 0.5
```

특정 clone만 지정:

```bat
python scripts\04_run_igg_product_fva.py --base C:\CHO_POC --conditions Clone08 Clone02 Clone09 --objective DM_igg_g --fraction 0.9 --bound-buffer 0.5
```

출력:

```text
results\tables\targeted_product_fva\targeted_product_fva_solution_summary.csv
results\tables\targeted_product_fva\targeted_product_fva_reaction_ranges.csv
results\tables\targeted_product_fva\targeted_product_fva_clone_summary_FILTERED.csv
results\tables\targeted_product_fva\targeted_product_fva_filter_QC.csv
```

핵심 해석:

```text
DM_igg_g objective를 최대치의 90% 이상 유지한 상태에서 가능한 pathway flux variability
```

큰 FVA range는 pathway activity가 아니라 flexibility입니다.

---

### Stage 5. 최종 report

```bat
python scripts\05_make_final_report.py --base C:\CHO_POC
```

출력:

```text
results\tables\FINAL_INTERPRETABLE_CLONE_SUMMARY.csv
results\tables\FINAL_INTERPRETATION_GUIDE.md
results\REPORT_INDEX.html
```

---

## 3. 내 데이터를 넣었을 때 어디부터 시작?

### 내 데이터가 이 양식이면 Stage 1부터

한 sheet에 아래처럼 되어 있으면 그대로 Stage 1부터 시작합니다.

```text
DAY
Sample ID 또는 Flask ID
Gluc
Lac
NH4+
Ala Arg Asn Asp Cys Gln Glu Gly His Ile Leu Lys Met Phe Pro Ser Thr Trp Tyr Val
Na+ K+ Ca++ pH PO2 PCO2 Osm
Total Density
Viable Density
Viability
Average Live Diameter
IgG
Culture Volume mL
Sample Removed mL
FunctionMax mL
CellBoost 7A mL
CellBoost 7B mL
FunctionMax Ala mM ...
CellBoost 7A Ala mM ...
CellBoost 7B Ala mM ...
```

명령어:

```bat
python scripts\01_prepare_exchange_rates.py --base C:\CHO_POC --raw-excel "C:\CHO_POC\data\metabolomics\raw\내파일.xlsx" --volume 50
```

그 다음 2 → 3 → 4 → 5 순서로 진행합니다.

### 이미 exchange_rates_feed_corrected.csv가 있다면 Stage 2부터

```text
data\metabolomics\processed\exchange_rates_feed_corrected.csv
```

가 이미 있으면:

```bat
python scripts\02_rank_clones.py --base C:\CHO_POC
python scripts\03_prepare_igg_objective.py --base C:\CHO_POC
python scripts\04_run_igg_product_fva.py --base C:\CHO_POC --top-n 3 --objective DM_igg_g
python scripts\05_make_final_report.py --base C:\CHO_POC
```

---

## 4. 결과 해석 요약

### Primary result

```text
clone_decision_summary.csv
FINAL_INTERPRETABLE_CLONE_SUMMARY.csv
```

주로 titer, qP, viability, exchange burden 기반입니다.

### Product-FVA result

```text
targeted_product_fva_clone_summary_FILTERED.csv
```

`DM_igg_g` objective 조건에서의 model-inferred pathway flexibility입니다.

### 주의

```text
FVA range가 크다 = pathway activity가 높다
```

가 아닙니다.

정확한 표현:

```text
larger FVA range indicates greater model-inferred flux flexibility under the IgG demand objective and measured exchange constraints.
```

---

## 5. 권장 보고 문장

```text
Feed-corrected extracellular exchange rates were applied as constraints to the iCHO3K model. Clone ranking was primarily based on productivity, qP, viability, and exchange-derived metabolic burden. The IgG demand reaction DM_igg_g was used as a product-relevant objective for targeted FVA. After removing bound-driven reactions, pathway-level FVA was interpreted as model-inferred metabolic flexibility rather than direct intracellular flux activity.
```

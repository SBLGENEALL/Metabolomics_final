@echo off
cd /d C:\CHO_POC
python scripts\00_RUN_ALL.py --base C:\CHO_POC
pause

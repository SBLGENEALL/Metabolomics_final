from __future__ import annotations

import argparse
import sys
from pathlib import Path
from _common import run_cmd, make_log, core_script


def main():
    ap = argparse.ArgumentParser(description="Stage 5: final interpretation tables and HTML report.")
    ap.add_argument("--base", default=".")
    args = ap.parse_args()

    base = Path(args.base).resolve()
    log = make_log(base, "05_make_final_report")

    run_cmd([
        sys.executable, str(core_script(base, "final_interpretable_summary_engine.py")),
        "--base", str(base),
    ], log, required=False)

    run_cmd([
        sys.executable, str(core_script(base, "summarize_results_engine.py")),
        "--base", str(base),
    ], log, required=False)

    print("[OK] Stage 5 complete.")
    print("Final interpretation:", base / "results" / "tables" / "FINAL_INTERPRETABLE_CLONE_SUMMARY.csv")
    print("HTML report:", base / "results" / "REPORT_INDEX.html")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from _common import run_cmd, make_log, ensure_dirs, pick_raw_excel


def main():
    ap = argparse.ArgumentParser(description="Run complete staged CHO metabolomics + IgG-targeted FVA pipeline.")
    ap.add_argument("--base", default=".")
    ap.add_argument("--raw-excel", default=None)
    ap.add_argument("--volume", type=float, default=50.0)
    ap.add_argument("--top-n", type=int, default=3)
    ap.add_argument("--objective", default="DM_igg_g")
    ap.add_argument("--fraction", type=float, default=0.9)
    ap.add_argument("--bound-buffer", type=float, default=0.5)
    ap.add_argument("--run-core-fva", action="store_true", help="Optional; slower. Default pipeline uses targeted product FVA instead.")
    args = ap.parse_args()

    base = Path(args.base).resolve()
    ensure_dirs(base)
    raw = pick_raw_excel(base, args.raw_excel)
    log = make_log(base, "00_RUN_ALL")

    print("[BASE]", base)
    print("[RAW]", raw)
    print("[LOG]", log)

    stages = [
        ["01_prepare_exchange_rates.py", "--base", str(base), "--raw-excel", str(raw), "--volume", str(args.volume)],
        ["02_rank_clones.py", "--base", str(base)],
        ["03_prepare_igg_objective.py", "--base", str(base), "--condition", "auto"],
        ["04_run_igg_product_fva.py", "--base", str(base), "--top-n", str(args.top_n), "--objective", args.objective, "--fraction", str(args.fraction), "--bound-buffer", str(args.bound_buffer)],
        ["05_make_final_report.py", "--base", str(base)],
    ]

    for st in stages:
        run_cmd([sys.executable, str(base / "scripts" / st[0]), *st[1:]], log, required=True)

    print("\n[DONE] Complete pipeline finished.")
    print("Main clone ranking:", base / "results" / "tables" / "clone_decision_summary.csv")
    print("Filtered product-FVA:", base / "results" / "tables" / "targeted_product_fva" / "targeted_product_fva_clone_summary_FILTERED.csv")
    print("Final interpretation:", base / "results" / "tables" / "FINAL_INTERPRETABLE_CLONE_SUMMARY.csv")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import sys
from pathlib import Path
import pandas as pd
from _common import run_cmd, make_log, ensure_dirs, core_script, pick_raw_excel


def main():
    ap = argparse.ArgumentParser(description="Stage 1: raw Excel -> process/metabolomics/exchange-rate CSVs.")
    ap.add_argument("--base", default=".")
    ap.add_argument("--raw-excel", required=False)
    ap.add_argument("--volume", type=float, default=50.0)
    args = ap.parse_args()

    base = Path(args.base).resolve()
    ensure_dirs(base)
    raw = pick_raw_excel(base, args.raw_excel)
    log = make_log(base, "01_prepare_exchange_rates")

    run_cmd([
        sys.executable, str(core_script(base, "prepare_exchange_rates_engine.py")),
        "--base", str(base),
        "--raw-excel", str(raw),
        "--volume", str(args.volume),
    ], log, required=True)

    p = base / "data" / "metabolomics" / "processed" / "exchange_rates_feed_corrected.csv"
    df = pd.read_csv(p)
    mets = sorted(df["metabolite"].dropna().astype(str).unique()) if "metabolite" in df.columns else []
    print("\n[CHECK] exchange-rate metabolite count =", len(mets))
    print("[CHECK] metabolites:", mets)
    if len(mets) < 10:
        print("[WARN] metabolite count is low. This is okay for limited data, but FVA/pathway interpretation will be weaker.")
    print("[OK] Stage 1 complete:", p)


if __name__ == "__main__":
    main()

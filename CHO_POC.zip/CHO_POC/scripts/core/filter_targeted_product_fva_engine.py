
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--fva-file", default="results/tables/targeted_product_fva/targeted_product_fva_reaction_ranges.csv")
    ap.add_argument("--solution-file", default="results/tables/targeted_product_fva/targeted_product_fva_solution_summary.csv")
    ap.add_argument("--max-absolute-bound", type=float, default=900.0, help="Exclude reactions touching +/- this value")
    ap.add_argument("--max-range", type=float, default=500.0, help="Exclude reactions with range above this value")
    ap.add_argument("--exclude-pathways", nargs="*", default=["amino_acid_transport"], help="Pathways to exclude from interpretable summary")
    args = ap.parse_args()

    base = Path(args.base).resolve()
    fva_path = Path(args.fva_file)
    if not fva_path.is_absolute():
        fva_path = base / fva_path

    sol_path = Path(args.solution_file)
    if not sol_path.is_absolute():
        sol_path = base / sol_path

    outdir = base / "results" / "tables" / "targeted_product_fva"
    outdir.mkdir(parents=True, exist_ok=True)

    fva = pd.read_csv(fva_path)
    for c in ["minimum", "maximum", "range", "objective_value"]:
        if c in fva.columns:
            fva[c] = pd.to_numeric(fva[c], errors="coerce")

    fva["touches_model_bound"] = (fva["maximum"].abs() >= args.max_absolute_bound) | (fva["minimum"].abs() >= args.max_absolute_bound)
    fva["range_too_large"] = fva["range"].abs() >= args.max_range
    fva["excluded_pathway"] = fva["pathway"].astype(str).isin(args.exclude_pathways)

    # Main interpretable filter:
    # remove model-bound-driven, extremely large-range, and broad transport pathways.
    filtered = fva[
        (~fva["touches_model_bound"])
        & (~fva["range_too_large"])
        & (~fva["excluded_pathway"])
    ].copy()

    fva.to_csv(outdir / "targeted_product_fva_reaction_ranges_with_flags.csv", index=False, encoding="utf-8-sig")
    filtered.to_csv(outdir / "targeted_product_fva_reaction_ranges_FILTERED.csv", index=False, encoding="utf-8-sig")

    if not filtered.empty:
        pathway_filtered = (
            filtered.groupby(["condition", "day_start", "day_end", "interval", "pathway"], as_index=False)
            .agg(
                filtered_fva_sum_range=("range", "sum"),
                filtered_fva_mean_range=("range", "mean"),
                filtered_fva_max_range=("range", "max"),
                n_filtered_reactions=("reaction", "nunique"),
                mean_minimum=("minimum", "mean"),
                mean_maximum=("maximum", "mean"),
            )
        )
        clone_filtered = (
            pathway_filtered.groupby(["condition", "pathway"], as_index=False)
            .agg(
                mean_filtered_fva_sum_range=("filtered_fva_sum_range", "mean"),
                mean_filtered_fva_mean_range=("filtered_fva_mean_range", "mean"),
                mean_n_filtered_reactions=("n_filtered_reactions", "mean"),
                n_intervals=("interval", "nunique"),
            )
        )
    else:
        pathway_filtered = pd.DataFrame()
        clone_filtered = pd.DataFrame()

    pathway_filtered.to_csv(outdir / "targeted_product_fva_pathway_summary_FILTERED.csv", index=False, encoding="utf-8-sig")
    clone_filtered.to_csv(outdir / "targeted_product_fva_clone_summary_FILTERED.csv", index=False, encoding="utf-8-sig")

    # QC summary
    qc = {
        "total_fva_rows": len(fva),
        "filtered_rows_kept": len(filtered),
        "excluded_touching_model_bound": int(fva["touches_model_bound"].sum()),
        "excluded_large_range": int(fva["range_too_large"].sum()),
        "excluded_pathway": int(fva["excluded_pathway"].sum()),
        "max_absolute_bound_threshold": args.max_absolute_bound,
        "max_range_threshold": args.max_range,
        "excluded_pathways": ";".join(args.exclude_pathways),
    }
    pd.DataFrame([qc]).to_csv(outdir / "targeted_product_fva_filter_QC.csv", index=False, encoding="utf-8-sig")

    if sol_path.exists():
        sol = pd.read_csv(sol_path)
        sol.to_csv(outdir / "targeted_product_fva_solution_summary_COPY.csv", index=False, encoding="utf-8-sig")

    md = []
    md.append("# Filtered product-objective FVA interpretation")
    md.append("")
    md.append("This filtered summary removes reactions likely dominated by open model bounds rather than biology:")
    md.append("")
    md.append(f"- reactions with |minimum| or |maximum| >= {args.max_absolute_bound}")
    md.append(f"- reactions with FVA range >= {args.max_range}")
    md.append(f"- broad excluded pathways: {', '.join(args.exclude_pathways)}")
    md.append("")
    md.append("Use unfiltered FVA as a feasibility/flexibility QC layer, but use filtered summaries for pathway interpretation.")
    md.append("")
    md.append("Important: a large FVA range means flexibility/underdetermination, not higher pathway activity.")
    md.append("")
    md.append("Generated files:")
    md.append("")
    md.append("- targeted_product_fva_reaction_ranges_with_flags.csv")
    md.append("- targeted_product_fva_reaction_ranges_FILTERED.csv")
    md.append("- targeted_product_fva_pathway_summary_FILTERED.csv")
    md.append("- targeted_product_fva_clone_summary_FILTERED.csv")
    md.append("- targeted_product_fva_filter_QC.csv")
    (outdir / "README_FILTERED_PRODUCT_FVA.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    print("[OK] saved filtered FVA outputs in:", outdir)
    print("[QC]")
    print(pd.DataFrame([qc]).to_string(index=False))

    if not clone_filtered.empty:
        print("\n[FILTERED CLONE SUMMARY TOP]")
        print(clone_filtered.sort_values("mean_filtered_fva_sum_range", ascending=False).head(40).to_string(index=False))
    else:
        print("\n[WARN] No reactions remained after filtering. Try --max-range 1000 or reduce filtering strictness.")


if __name__ == "__main__":
    main()

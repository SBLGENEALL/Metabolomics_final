
from __future__ import annotations

import argparse
import math
from pathlib import Path
import numpy as np
import pandas as pd
import cobra
from cobra.flux_analysis import pfba, flux_variability_analysis


DEFAULT_OPEN = {
    "EX_h_e": (-1000, 1000),
    "EX_h2o_e": (-1000, 1000),
    "EX_o2_e": (-1000, 1000),
    "EX_co2_e": (-1000, 1000),
    "EX_hco3_e": (-1000, 1000),
    "EX_pi_e": (-1000, 1000),
    "EX_so4_e": (-1000, 1000),
}


def clean_condition(x):
    s = str(x).strip()
    return s[:-2] if s.endswith(".0") else s


def clean_id(x):
    return str(x).strip().replace("\ufeff", "").replace("\u200b", "")


def finite(x):
    try:
        return math.isfinite(float(x))
    except Exception:
        return False


def pick_model(base: Path, model_file: str | None) -> Path:
    if model_file:
        p = Path(model_file)
        return p if p.is_absolute() else base / p

    candidates = [
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.json",
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.xml",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError("Model file not found. Use --model-file")


def load_model(path: Path):
    if path.suffix.lower() == ".json":
        return cobra.io.load_json_model(str(path))
    return cobra.io.read_sbml_model(str(path))


def strict_bounds(row, buffer=0.5):
    rate = row.get("rate")
    if finite(rate):
        rate = float(rate)
        if rate < 0:
            lb, ub = rate * (1 + buffer), rate * (1 - buffer)
        else:
            lb, ub = rate * (1 - buffer), rate * (1 + buffer)
    elif finite(row.get("lower_bound")) and finite(row.get("upper_bound")):
        lb, ub = float(row["lower_bound"]), float(row["upper_bound"])
    else:
        return None

    if lb > ub:
        lb, ub = ub, lb
    return max(lb, -1000.0), min(ub, 1000.0)


def apply_exchange_constraints(model, interval_df, bound_buffer):
    applied = []
    warnings = []

    for rid, bounds in DEFAULT_OPEN.items():
        if rid in model.reactions:
            model.reactions.get_by_id(rid).bounds = bounds

    for _, row in interval_df.drop_duplicates(subset=["exchange_rxn"], keep="last").iterrows():
        rid = clean_id(row.get("exchange_rxn", ""))
        if rid not in model.reactions:
            warnings.append({"reaction": rid, "issue": "missing_in_model", "metabolite": row.get("metabolite", "")})
            continue
        b = strict_bounds(row, bound_buffer)
        if b is None:
            warnings.append({"reaction": rid, "issue": "invalid_rate", "metabolite": row.get("metabolite", "")})
            continue
        rxn = model.reactions.get_by_id(rid)
        rxn.bounds = b
        applied.append({
            "reaction": rid,
            "metabolite": row.get("metabolite", ""),
            "rate": row.get("rate", np.nan),
            "lower_bound": rxn.lower_bound,
            "upper_bound": rxn.upper_bound,
            "excludes_zero": not (rxn.lower_bound <= 0 <= rxn.upper_bound),
        })

    return pd.DataFrame(applied), pd.DataFrame(warnings)


def select_conditions(base: Path, conditions_arg, top_n):
    if conditions_arg:
        return [clean_condition(x) for x in conditions_arg]

    summary_path = base / "results" / "tables" / "clone_decision_summary.csv"
    if not summary_path.exists():
        raise FileNotFoundError("No --conditions given and clone_decision_summary.csv not found.")
    df = pd.read_csv(summary_path)
    df["condition"] = df["condition"].map(clean_condition)
    if "rank" in df.columns:
        df = df.sort_values("rank")
    elif "decision_score_0to1" in df.columns:
        df = df.sort_values("decision_score_0to1", ascending=False)
    return df["condition"].head(top_n).tolist()


def choose_objective(base: Path, model, objective):
    if objective and objective.lower() != "auto":
        if objective not in model.reactions:
            raise ValueError(f"Objective reaction not in model: {objective}")
        return objective

    cand = base / "results" / "tables" / "product_objective_candidates.csv"
    if not cand.exists():
        raise FileNotFoundError("product_objective_candidates.csv not found. Run 21_find_product_objective.py first or provide --objective.")
    df = pd.read_csv(cand)
    if df.empty:
        raise ValueError("No objective candidates found.")

    # Prefer product_or_IgG with nonzero objective_test, then biomass.
    df["objective_test_value_num"] = pd.to_numeric(df.get("objective_test_value"), errors="coerce")
    df["nonzero_test"] = df["objective_test_value_num"].abs() > 1e-12
    cat_rank = {"product_or_IgG": 0, "biomass": 1, "other_candidate": 2}
    df["category_rank"] = df["category"].map(cat_rank).fillna(9)
    df = df.sort_values(["category_rank", "nonzero_test", "auto_score"], ascending=[True, False, False])

    for rid in df["reaction"].astype(str):
        if rid in model.reactions and "oglna" not in rid.lower():
            return rid

    raise ValueError("No usable objective candidate found.")


def load_pathway(pathway_file: Path, model):
    df = pd.read_csv(pathway_file)
    if "pathway" not in df.columns or "reaction" not in df.columns:
        raise ValueError("pathway file must contain pathway,reaction")
    df["reaction"] = df["reaction"].map(clean_id)
    df["pathway"] = df["pathway"].astype(str)
    rxns = {r.id for r in model.reactions}
    df = df[df["reaction"].isin(rxns)].drop_duplicates(["pathway", "reaction"]).copy()
    if df.empty:
        raise ValueError("No pathway reactions overlap model.")
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--rates-file", default="data/metabolomics/processed/exchange_rates_feed_corrected.csv")
    ap.add_argument("--pathway-file", default="results/tables/pathway_reaction_sets_core.csv")
    ap.add_argument("--model-file", default=None)
    ap.add_argument("--objective", default="auto", help="auto or exact product/IgG/biomass reaction ID")
    ap.add_argument("--conditions", nargs="*", default=None, help="Clone IDs to run. Example: Clone08 Clone02 Clone09")
    ap.add_argument("--top-n", type=int, default=3)
    ap.add_argument("--bound-buffer", type=float, default=0.5)
    ap.add_argument("--fraction", type=float, default=0.9)
    ap.add_argument("--processes", type=int, default=1)
    args = ap.parse_args()

    base = Path(args.base).resolve()
    outdir = base / "results" / "tables" / "targeted_product_fva"
    outdir.mkdir(parents=True, exist_ok=True)

    rates_path = Path(args.rates_file)
    if not rates_path.is_absolute():
        rates_path = base / rates_path

    pathway_path = Path(args.pathway_file)
    if not pathway_path.is_absolute():
        pathway_path = base / pathway_path

    model_path = pick_model(base, args.model_file)
    base_model = load_model(model_path)
    objective = choose_objective(base, base_model, args.objective)
    pathway = load_pathway(pathway_path, base_model)
    reaction_list = sorted(pathway["reaction"].unique())

    conditions = select_conditions(base, args.conditions, args.top_n)

    rates = pd.read_csv(rates_path)
    rates["condition"] = rates["condition"].map(clean_condition)
    rates["exchange_rxn"] = rates["exchange_rxn"].map(clean_id)
    rates["day_start"] = pd.to_numeric(rates["day_start"], errors="coerce")
    rates["day_end"] = pd.to_numeric(rates["day_end"], errors="coerce")
    rates["rate"] = pd.to_numeric(rates["rate"], errors="coerce")
    rates = rates[rates["condition"].isin(conditions)].copy()

    intervals = (
        rates[["condition", "day_start", "day_end"]]
        .dropna()
        .drop_duplicates()
        .sort_values(["condition", "day_start", "day_end"])
    )

    print("[INFO] model:", model_path)
    print("[INFO] objective:", objective, base_model.reactions.get_by_id(objective).name)
    print("[INFO] conditions:", conditions)
    print("[INFO] pathway reactions:", len(reaction_list))
    print("[INFO] fraction_of_optimum:", args.fraction)

    sol_rows = []
    fva_rows = []
    warn_rows = []
    applied_rows = []

    for _, iv in intervals.iterrows():
        cond = clean_condition(iv["condition"])
        d0 = float(iv["day_start"])
        d1 = float(iv["day_end"])
        sub = rates[(rates["condition"] == cond) & (rates["day_start"] == d0) & (rates["day_end"] == d1)].copy()

        model = load_model(model_path)
        model.objective = objective

        applied, warn = apply_exchange_constraints(model, sub, args.bound_buffer)
        if not applied.empty:
            applied.insert(0, "condition", cond)
            applied.insert(1, "day_start", d0)
            applied.insert(2, "day_end", d1)
            applied_rows.append(applied)
        if not warn.empty:
            warn.insert(0, "condition", cond)
            warn.insert(1, "day_start", d0)
            warn.insert(2, "day_end", d1)
            warn_rows.append(warn)

        sol = model.optimize()
        objective_value = sol.objective_value if sol.status == "optimal" else np.nan

        try:
            psol = pfba(model) if sol.status == "optimal" else None
            pfba_objective = psol.objective_value if psol is not None else np.nan
            flux = psol.fluxes if psol is not None else sol.fluxes
        except Exception:
            pfba_objective = np.nan
            flux = sol.fluxes

        nonzero_model = int((pd.to_numeric(flux, errors="coerce").abs() > 1e-10).sum())
        obj_flux = float(flux.get(objective, np.nan)) if sol.status == "optimal" else np.nan

        sol_rows.append({
            "condition": cond,
            "day_start": d0,
            "day_end": d1,
            "interval": f"{d0:g}-{d1:g}",
            "status": sol.status,
            "objective": objective,
            "objective_flux": obj_flux,
            "objective_value": objective_value,
            "pfba_objective": pfba_objective,
            "applied_constraints": len(applied),
            "constraints_excluding_zero": int(applied["excludes_zero"].sum()) if not applied.empty else 0,
            "nonzero_model_fluxes": nonzero_model,
        })

        print(f"[RUN] {cond} {d0:g}-{d1:g} status={sol.status} objective={objective_value} obj_flux={obj_flux} constraints={len(applied)}")

        if sol.status != "optimal":
            continue
        if pd.isna(objective_value) or abs(float(objective_value)) <= 1e-12:
            warn_rows.append(pd.DataFrame([{
                "condition": cond,
                "day_start": d0,
                "day_end": d1,
                "reaction": objective,
                "issue": "objective_zero",
                "detail": "FVA fraction constraint is weak because max objective is zero.",
            }]))

        try:
            fva = flux_variability_analysis(
                model,
                reaction_list=reaction_list,
                fraction_of_optimum=args.fraction,
                processes=args.processes,
            ).reset_index().rename(columns={"index": "reaction"})
            fva["reaction"] = fva["reaction"].map(clean_id)
            fva["range"] = fva["maximum"] - fva["minimum"]
            fva["condition"] = cond
            fva["day_start"] = d0
            fva["day_end"] = d1
            fva["interval"] = f"{d0:g}-{d1:g}"
            fva["objective"] = objective
            fva["objective_value"] = objective_value
            fva = fva.merge(pathway[["pathway", "reaction"]].drop_duplicates(), on="reaction", how="left")
            fva_rows.append(fva)
        except Exception as e:
            warn_rows.append(pd.DataFrame([{
                "condition": cond,
                "day_start": d0,
                "day_end": d1,
                "reaction": "",
                "issue": "fva_failed",
                "detail": str(e),
            }]))

    sol_df = pd.DataFrame(sol_rows)
    fva_df = pd.concat(fva_rows, ignore_index=True) if fva_rows else pd.DataFrame()
    warn_df = pd.concat(warn_rows, ignore_index=True) if warn_rows else pd.DataFrame()
    applied_df = pd.concat(applied_rows, ignore_index=True) if applied_rows else pd.DataFrame()

    sol_df.to_csv(outdir / "targeted_product_fva_solution_summary.csv", index=False, encoding="utf-8-sig")
    fva_df.to_csv(outdir / "targeted_product_fva_reaction_ranges.csv", index=False, encoding="utf-8-sig")
    warn_df.to_csv(outdir / "targeted_product_fva_warnings.csv", index=False, encoding="utf-8-sig")
    applied_df.to_csv(outdir / "targeted_product_fva_applied_constraints.csv", index=False, encoding="utf-8-sig")

    if not fva_df.empty:
        pathway_summary = (
            fva_df.groupby(["condition", "day_start", "day_end", "interval", "pathway"], as_index=False)
            .agg(
                fva_sum_range=("range", "sum"),
                fva_mean_range=("range", "mean"),
                fva_max_range=("range", "max"),
                n_fva_reactions=("reaction", "nunique"),
                mean_minimum=("minimum", "mean"),
                mean_maximum=("maximum", "mean"),
            )
        )
        pathway_summary.to_csv(outdir / "targeted_product_fva_pathway_summary.csv", index=False, encoding="utf-8-sig")

        clone_summary = (
            pathway_summary.groupby(["condition", "pathway"], as_index=False)
            .agg(
                mean_fva_sum_range=("fva_sum_range", "mean"),
                mean_fva_mean_range=("fva_mean_range", "mean"),
                mean_n_fva_reactions=("n_fva_reactions", "mean"),
                n_intervals=("interval", "nunique"),
            )
        )
        clone_summary.to_csv(outdir / "targeted_product_fva_clone_summary.csv", index=False, encoding="utf-8-sig")

        print("\n[TOP FVA PATHWAY SUMMARY]")
        print(pathway_summary.sort_values("fva_sum_range", ascending=False).head(30).to_string(index=False))

    print("[OK] saved:", outdir)


if __name__ == "__main__":
    main()

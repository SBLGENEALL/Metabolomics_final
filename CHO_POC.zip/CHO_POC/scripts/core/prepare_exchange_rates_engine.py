
from __future__ import annotations

import argparse
import re
from pathlib import Path
import numpy as np
import pandas as pd


MET_INFO = {
    # central / routine metabolites
    "Glucose":   {"aliases": ["glucose", "gluc", "glc"], "ex": "EX_glc_e"},
    "Lactate":   {"aliases": ["lactate", "lac"], "ex": "EX_lac_L_e"},
    "Glutamine": {"aliases": ["glutamine", "gln"], "ex": "EX_gln_L_e"},
    "Glutamate": {"aliases": ["glutamate", "glu"], "ex": "EX_glu_L_e"},
    "Ammonia":   {"aliases": ["ammonia", "ammonium", "nh4", "nh4+"], "ex": "EX_nh4_e"},

    # 20 amino acids
    "Alanine":       {"aliases": ["alanine", "ala"], "ex": "EX_ala_L_e"},
    "Arginine":      {"aliases": ["arginine", "arg"], "ex": "EX_arg_L_e"},
    "Asparagine":    {"aliases": ["asparagine", "asn"], "ex": "EX_asn_L_e"},
    "Aspartate":     {"aliases": ["aspartate", "asp", "aspartic acid"], "ex": "EX_asp_L_e"},
    "Cysteine":      {"aliases": ["cysteine", "cys"], "ex": "EX_cys_L_e"},
    "Glycine":       {"aliases": ["glycine", "gly"], "ex": "EX_gly_e"},
    "Histidine":     {"aliases": ["histidine", "his"], "ex": "EX_his_L_e"},
    "Isoleucine":    {"aliases": ["isoleucine", "ile"], "ex": "EX_ile_L_e"},
    "Leucine":       {"aliases": ["leucine", "leu"], "ex": "EX_leu_L_e"},
    "Lysine":        {"aliases": ["lysine", "lys"], "ex": "EX_lys_L_e"},
    "Methionine":    {"aliases": ["methionine", "met"], "ex": "EX_met_L_e"},
    "Phenylalanine": {"aliases": ["phenylalanine", "phe"], "ex": "EX_phe_L_e"},
    "Proline":       {"aliases": ["proline", "pro"], "ex": "EX_pro_L_e"},
    "Serine":        {"aliases": ["serine", "ser"], "ex": "EX_ser_L_e"},
    "Threonine":     {"aliases": ["threonine", "thr"], "ex": "EX_thr_L_e"},
    "Tryptophan":    {"aliases": ["tryptophan", "trp"], "ex": "EX_trp_L_e"},
    "Tyrosine":      {"aliases": ["tyrosine", "tyr"], "ex": "EX_tyr_L_e"},
    "Valine":        {"aliases": ["valine", "val"], "ex": "EX_val_L_e"},

    # Sometimes AA panels include these separately; they are optional and will be used if present.
    "Cystine":       {"aliases": ["cystine", "cystine2", "cyss"], "ex": "EX_cyss_e"},
}

DAY_ALIASES = ["day", "culture day", "sample day", "sampling day", "day1"]
COND_ALIASES = ["sample id", "sample_id", "flask id", "flask_id", "condition", "clone", "id"]


def norm(x) -> str:
    s = str(x).strip().lower()
    s = s.replace("_", " ").replace("-", " ")
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def compact(x) -> str:
    return re.sub(r"[^a-z0-9]+", "", norm(x))


def parse_day_value(x):
    if pd.isna(x):
        return None
    if isinstance(x, (int, float, np.integer, np.floating)):
        return float(x)
    s = str(x).strip()
    if not s:
        return None
    try:
        return float(s)
    except Exception:
        pass
    m = re.search(r"(?:day|d)\s*[_-]?\s*([0-9]+(?:\.[0-9]+)?)", s, flags=re.I)
    if m:
        return float(m.group(1))
    return None


def find_col(columns, aliases):
    nmap = {norm(c): c for c in columns}
    cmap = {compact(c): c for c in columns}
    for a in aliases:
        if norm(a) in nmap:
            return nmap[norm(a)]
        if compact(a) in cmap:
            return cmap[compact(a)]
    return None


def title_feed_name(feed: str) -> str:
    s = re.sub(r"\s+", " ", str(feed).strip())
    low = s.lower()
    known = [
        ("cell boost", "CellBoost"),
        ("cellboost", "CellBoost"),
        ("function max", "FunctionMax"),
        ("functionmax", "FunctionMax"),
        ("feed 4", "Feed4"),
        ("feed4", "Feed4"),
        ("glucose feed", "Glucose Feed"),
    ]
    for k, v in known:
        if low == k:
            return v
        if low.startswith(k + " "):
            return v + s[len(k):]
    return " ".join(w[:1].upper() + w[1:] for w in s.split())


def met_alias_lookup():
    d = {}
    for met, info in MET_INFO.items():
        for a in info["aliases"]:
            d[compact(a)] = met
    return d


def canonical_met(token: str):
    return met_alias_lookup().get(compact(token))


def detect_header_row(xlsx: Path, sheet_name: str):
    raw = pd.read_excel(xlsx, sheet_name=sheet_name, header=None, engine="openpyxl")
    aliases = DAY_ALIASES + COND_ALIASES
    for info in MET_INFO.values():
        aliases += info["aliases"]
    aliases += ["culture volume ml", "sample removed ml", "functionmax ml", "cellboost 7a ml", "cellboost 7b ml"]
    alias_set = {compact(a) for a in aliases}

    best_i, best_score = 0, -1
    for i in range(min(80, len(raw))):
        vals = [compact(v) for v in raw.iloc[i].tolist()]
        score = sum(1 for v in vals if v in alias_set)
        if score > best_score:
            best_i, best_score = i, score
        if score >= 5:
            return i
    return best_i


def detect_metabolite_concentration_cols(columns):
    """
    Detect sample concentration columns such as Ala, Alanine, Gluc, NH4+.
    Excludes feed composition columns such as FunctionMax Ala mM.
    """
    detected = {}
    for col in columns:
        c = compact(col)
        n = norm(col)

        # Skip feed composition / volume-like columns
        if "mm" in n and len(n.split()) >= 2:
            continue
        if c.endswith("ml") or "feed" in n or "cellboost" in n or "functionmax" in n:
            continue

        met = canonical_met(str(col))
        if met:
            detected[met] = col
    return detected


def detect_feed_columns(columns):
    feed_volume_cols = {}
    feed_comp_cols = {}

    skip_compact = {
        "day", "day1", "sampleid", "flaskid", "condition", "clone",
        "culturevolumeml", "sampleremovedml",
        "totaldesity", "totaldensity", "viabledensity", "viability", "averagelivediameter", "igg",
        "ph", "po2", "pco2", "osm", "na", "k", "ca",
    }
    for met, info in MET_INFO.items():
        for a in info["aliases"]:
            skip_compact.add(compact(a))

    for col in columns:
        col0 = str(col).strip()
        n = norm(col0)
        c = compact(col0)

        if c in skip_compact:
            continue

        if c in {"glucosefeedml", "glucfeedml", "glucoseshotml"}:
            feed_volume_cols["Glucose Feed"] = col0
            continue
        if c in {"glucosefeedconcmm", "glucosefeedconcentrationmm", "glucfeedconcmm", "glucosestockmm"}:
            feed_comp_cols[("Glucose Feed", "Glucose")] = col0
            continue

        # Feed volume: "<feed> mL"
        if re.search(r"(^| )ml$", n, flags=re.I) and "mm" not in n:
            feed = re.sub(r"(?i)\s+volume\s+ml$", "", n).strip()
            feed = re.sub(r"(?i)\s+ml$", "", feed).strip()
            if feed and feed not in {"culture volume", "sample removed"}:
                feed_volume_cols[title_feed_name(feed)] = col0
            continue

        # Feed composition: "<feed> <met> mM"
        if "mm" in n:
            parts = [p for p in n.split() if compact(p) not in {"mm", "conc", "concentration"}]
            if len(parts) >= 2:
                met = canonical_met(parts[-1])
                if met:
                    feed = " ".join(parts[:-1]).strip()
                    feed_comp_cols[(title_feed_name(feed), met)] = col0
    return feed_volume_cols, feed_comp_cols


def read_raw_long(raw_excel: Path, default_volume: float):
    xl = pd.ExcelFile(raw_excel, engine="openpyxl")
    process_rows = []
    metab_rows = []
    feed_rows = []
    debug_rows = []

    for sheet in xl.sheet_names:
        header = detect_header_row(raw_excel, sheet)
        df = pd.read_excel(raw_excel, sheet_name=sheet, header=header, engine="openpyxl")
        df = df.dropna(axis=0, how="all").dropna(axis=1, how="all")
        df.columns = [str(c).strip() for c in df.columns]

        day_col = find_col(df.columns, DAY_ALIASES)
        cond_col = find_col(df.columns, COND_ALIASES)
        if cond_col is None:
            cols = list(df.columns)
            if day_col in cols:
                cols.remove(day_col)
            cond_col = cols[0] if cols else None
        if cond_col is None:
            continue

        culture_vol_col = find_col(df.columns, ["culture volume ml", "culture_volume_ml", "volume ml", "working volume ml"])
        sample_removed_col = find_col(df.columns, ["sample removed ml", "sample_removed_ml", "sampling volume ml", "sample volume ml"])
        vcd_col = find_col(df.columns, ["viable density", "viable density 10e6 cells/ml", "vcd", "vcd 10e6 cells/ml"])
        viability_col = find_col(df.columns, ["viability", "viability %", "viability_pct"])
        igg_col = find_col(df.columns, ["igg", "titer", "titer mg/l", "igg mg/l"])

        met_cols = detect_metabolite_concentration_cols(df.columns)
        feed_volume_cols, feed_comp_cols = detect_feed_columns(df.columns)

        debug_rows.append({
            "sheet": sheet,
            "header_row": header,
            "day_col": day_col,
            "condition_col": cond_col,
            "culture_volume_col": culture_vol_col,
            "vcd_col": vcd_col,
            "igg_col": igg_col,
            "detected_metabolite_cols": "; ".join(f"{m}={c}" for m, c in sorted(met_cols.items())),
            "detected_feed_volume_cols": "; ".join(f"{k}={v}" for k, v in feed_volume_cols.items()),
            "detected_feed_composition_cols": "; ".join(f"{k[0]}:{k[1]}={v}" for k, v in feed_comp_cols.items()),
        })

        if day_col:
            days = df[day_col].apply(parse_day_value).ffill()
        else:
            days = pd.Series([parse_day_value(sheet)] * len(df), index=df.index)

        for idx, r in df.iterrows():
            cond = str(r.get(cond_col, "")).strip()
            if not cond or cond.lower() == "nan":
                continue
            day = days.loc[idx]
            if day is None or pd.isna(day):
                continue

            cv = pd.to_numeric(r.get(culture_vol_col, np.nan), errors="coerce") if culture_vol_col else np.nan
            sr = pd.to_numeric(r.get(sample_removed_col, np.nan), errors="coerce") if sample_removed_col else np.nan
            vcd = pd.to_numeric(r.get(vcd_col, np.nan), errors="coerce") if vcd_col else np.nan
            viab = pd.to_numeric(r.get(viability_col, np.nan), errors="coerce") if viability_col else np.nan
            igg = pd.to_numeric(r.get(igg_col, np.nan), errors="coerce") if igg_col else np.nan

            process_rows.append({
                "condition": cond,
                "day": float(day),
                "culture_volume_mL": float(cv) if pd.notna(cv) else float(default_volume),
                "sample_removed_mL": float(sr) if pd.notna(sr) else 0.0,
                "vcd_10e6_cells_mL": float(vcd) if pd.notna(vcd) else np.nan,
                "viability_pct": float(viab) if pd.notna(viab) else np.nan,
                "titer_g_L": float(igg) / 1000.0 if pd.notna(igg) else np.nan,
                "source_sheet": sheet,
            })

            for met, col in met_cols.items():
                val = pd.to_numeric(r.get(col, np.nan), errors="coerce")
                if pd.notna(val):
                    metab_rows.append({
                        "condition": cond,
                        "day": float(day),
                        "metabolite": met,
                        "concentration": float(val),
                        "unit": "mM",
                        "source_column": col,
                        "source_sheet": sheet,
                    })

            for feed, col in feed_volume_cols.items():
                vol = pd.to_numeric(r.get(col, np.nan), errors="coerce")
                if pd.notna(vol) and float(vol) != 0:
                    feed_rows.append({
                        "condition": cond,
                        "day": float(day),
                        "feed_name": feed,
                        "event_type": "volume",
                        "volume_mL": float(vol),
                        "metabolite": "",
                        "concentration_mM": np.nan,
                        "amount_umol": np.nan,
                        "source_column": col,
                        "source_sheet": sheet,
                    })

            for (feed, met), col in feed_comp_cols.items():
                conc = pd.to_numeric(r.get(col, np.nan), errors="coerce")
                if pd.notna(conc):
                    vol_col = feed_volume_cols.get(feed)
                    vol = pd.to_numeric(r.get(vol_col, np.nan), errors="coerce") if vol_col else np.nan
                    feed_rows.append({
                        "condition": cond,
                        "day": float(day),
                        "feed_name": feed,
                        "event_type": "composition",
                        "volume_mL": float(vol) if pd.notna(vol) else np.nan,
                        "metabolite": met,
                        "concentration_mM": float(conc),
                        "amount_umol": float(vol) * float(conc) if pd.notna(vol) else np.nan,
                        "source_column": col,
                        "source_sheet": sheet,
                    })

    return pd.DataFrame(process_rows), pd.DataFrame(metab_rows), pd.DataFrame(feed_rows), pd.DataFrame(debug_rows)


def feed_amount_umol(feed_long: pd.DataFrame, condition: str, d0: float, d1: float, metabolite: str) -> tuple[float, str]:
    if feed_long.empty:
        return 0.0, "no_feed_table"
    sub = feed_long[
        (feed_long["condition"].astype(str) == str(condition))
        & (pd.to_numeric(feed_long["day"], errors="coerce") > d0)
        & (pd.to_numeric(feed_long["day"], errors="coerce") <= d1)
        & (feed_long["event_type"] == "composition")
        & (feed_long["metabolite"] == metabolite)
    ].copy()
    if sub.empty:
        return 0.0, "no_feed_composition_used_for_this_metabolite"
    amount = pd.to_numeric(sub["amount_umol"], errors="coerce").fillna(0).sum()
    notes = []
    for _, r in sub.iterrows():
        if pd.notna(r.get("amount_umol")) and float(r.get("amount_umol")) != 0:
            notes.append(f"{r['feed_name']}_{metabolite}_umol={float(r['amount_umol']):g}")
    return float(amount), "; ".join(notes) if notes else "feed_composition_zero_or_volume_missing"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--raw-excel", required=True)
    ap.add_argument("--volume", type=float, default=50.0)
    ap.add_argument("--bound-buffer", type=float, default=0.20)
    args = ap.parse_args()

    base = Path(args.base)
    raw_excel = Path(args.raw_excel)
    if not raw_excel.is_absolute():
        raw_excel = base / raw_excel

    outdir = base / "data" / "metabolomics" / "processed"
    outdir.mkdir(parents=True, exist_ok=True)

    process, metab, feed_long, debug = read_raw_long(raw_excel, default_volume=args.volume)

    if process.empty:
        raise ValueError("No process rows parsed from raw Excel.")
    if metab.empty:
        raise ValueError("No metabolite rows parsed from raw Excel.")

    process["condition"] = process["condition"].astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
    metab["condition"] = metab["condition"].astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
    if not feed_long.empty:
        feed_long["condition"] = feed_long["condition"].astype(str).str.strip().str.replace(r"\.0$", "", regex=True)

    process["day"] = pd.to_numeric(process["day"], errors="coerce")
    metab["day"] = pd.to_numeric(metab["day"], errors="coerce")
    metab["concentration"] = pd.to_numeric(metab["concentration"], errors="coerce")

    # Calculate interval IVCD and qP approximately if possible.
    process = process.sort_values(["condition", "day"]).copy()
    process["ivcd_10e6_cell_day_mL"] = np.nan
    process["qP_pg_cell_day"] = np.nan

    for cond, sub_idx in process.groupby("condition").groups.items():
        idxs = list(sub_idx)
        sub = process.loc[idxs].sort_values("day")
        cumulative_ivcd = 0.0
        prev = None
        for i, row in sub.iterrows():
            if prev is not None:
                dt = float(row["day"] - prev["day"])
                if dt > 0 and pd.notna(row["vcd_10e6_cells_mL"]) and pd.notna(prev["vcd_10e6_cells_mL"]):
                    interval_ivcd = ((float(row["vcd_10e6_cells_mL"]) + float(prev["vcd_10e6_cells_mL"])) / 2.0) * dt
                    cumulative_ivcd += interval_ivcd
                    process.loc[i, "ivcd_10e6_cell_day_mL"] = cumulative_ivcd
                    if pd.notna(row.get("titer_g_L")) and pd.notna(prev.get("titer_g_L")) and interval_ivcd > 0:
                        # g/L = pg/mL? 1 g/L = 1e9 pg/mL; qP = delta pg/mL / (10e6 cell-day/mL) = 100 * delta_g_L / IVCD
                        process.loc[i, "qP_pg_cell_day"] = (float(row["titer_g_L"]) - float(prev["titer_g_L"])) * 100.0 / interval_ivcd
            else:
                process.loc[i, "ivcd_10e6_cell_day_mL"] = 0.0
            prev = row

    # Save converted tables with AA included
    process.to_csv(outdir / "converted_process_data.csv", index=False, encoding="utf-8-sig")
    metab.to_csv(outdir / "converted_extracellular_metabolomics.csv", index=False, encoding="utf-8-sig")
    feed_long.to_csv(outdir / "feed_events_parsed_long.csv", index=False, encoding="utf-8-sig")
    debug.to_csv(outdir / "aa_feed_column_detection_debug.csv", index=False, encoding="utf-8-sig")

    # Exchange rates
    proc_key = process.set_index(["condition", "day"])
    avg_metab = (
        metab.dropna(subset=["condition", "day", "metabolite", "concentration"])
        .groupby(["condition", "day", "metabolite"], as_index=False)["concentration"]
        .mean()
    )

    rows = []
    for cond in sorted(avg_metab["condition"].astype(str).unique()):
        cond_metab = avg_metab[avg_metab["condition"].astype(str) == cond]
        days = sorted(cond_metab["day"].dropna().unique())
        for d0, d1 in zip(days[:-1], days[1:]):
            m0 = cond_metab[cond_metab["day"] == d0].set_index("metabolite")["concentration"]
            m1 = cond_metab[cond_metab["day"] == d1].set_index("metabolite")["concentration"]

            try:
                p0 = proc_key.loc[(cond, d0)]
                p1 = proc_key.loc[(cond, d1)]
            except KeyError:
                continue

            if pd.isna(p0.get("vcd_10e6_cells_mL")) or pd.isna(p1.get("vcd_10e6_cells_mL")):
                continue

            vcd0 = float(p0["vcd_10e6_cells_mL"])
            vcd1 = float(p1["vcd_10e6_cells_mL"])
            vol0 = float(p0.get("culture_volume_mL", args.volume))
            vol1 = float(p1.get("culture_volume_mL", args.volume))
            avg_vol = (vol0 + vol1) / 2.0
            delta_day = float(d1 - d0)
            if delta_day <= 0:
                continue

            total_ivcd = ((vcd0 + vcd1) / 2.0) * delta_day * avg_vol
            if total_ivcd <= 0:
                continue

            for met in sorted(set(m0.index).intersection(set(m1.index))):
                if met not in MET_INFO:
                    continue
                c0 = float(m0.loc[met])
                c1 = float(m1.loc[met])
                start_umol = c0 * vol0
                end_umol = c1 * vol1
                feed_umol, note = feed_amount_umol(feed_long, cond, d0, d1, met)
                cellular_net_umol = end_umol - start_umol - feed_umol
                rate = cellular_net_umol / total_ivcd

                if rate < 0:
                    lb, ub = rate * (1 + args.bound_buffer), rate * (1 - args.bound_buffer)
                else:
                    lb, ub = rate * (1 - args.bound_buffer), rate * (1 + args.bound_buffer)
                if lb > ub:
                    lb, ub = ub, lb

                rows.append({
                    "condition": cond,
                    "metabolite": met,
                    "exchange_rxn": MET_INFO[met]["ex"],
                    "rate": rate,
                    "rate_type": "uptake" if rate < 0 else "secretion",
                    "unit": "mmol_per_1e9_cells_day_feed_corrected",
                    "day_start": d0,
                    "day_end": d1,
                    "lower_bound": lb,
                    "upper_bound": ub,
                    "source": "20AA_feed_corrected_mass_balance_v4",
                    "start_conc_mM": c0,
                    "end_conc_mM": c1,
                    "start_volume_mL": vol0,
                    "end_volume_mL": vol1,
                    "feed_amount_umol": feed_umol,
                    "cellular_net_umol": cellular_net_umol,
                    "total_ivcd_10e6_cell_day": total_ivcd,
                    "note": note,
                })

    rates = pd.DataFrame(rows)
    rates.to_csv(outdir / "exchange_rates_feed_corrected.csv", index=False, encoding="utf-8-sig")
    rates.to_csv(outdir / "exchange_rates_from_user_format.csv", index=False, encoding="utf-8-sig")

    print("[OK] saved:", outdir / "converted_process_data.csv")
    print("[OK] saved:", outdir / "converted_extracellular_metabolomics.csv")
    print("[OK] saved:", outdir / "exchange_rates_feed_corrected.csv")
    print("[OK] saved:", outdir / "aa_feed_column_detection_debug.csv")

    print("\n[METABOLITES IN CONVERTED DATA]")
    print(sorted(metab["metabolite"].dropna().unique()))
    print("count =", metab["metabolite"].nunique())

    print("\n[METABOLITES IN EXCHANGE RATES]")
    print(sorted(rates["metabolite"].dropna().unique()))
    print("count =", rates["metabolite"].nunique())

    print("\n[PREVIEW]")
    print(rates.head(40).to_string(index=False))


if __name__ == "__main__":
    main()

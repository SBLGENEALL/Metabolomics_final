
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd


def clean_condition_series(s):
    return s.astype(str).str.strip().str.replace(r"\.0$", "", regex=True)


def minmax_high(s):
    s = pd.to_numeric(s, errors="coerce")
    out = pd.Series(0.5, index=s.index, dtype=float)
    valid = s.dropna()
    if valid.empty or valid.max() == valid.min():
        return out
    out.loc[s.notna()] = (s.loc[s.notna()] - valid.min()) / (valid.max() - valid.min())
    return out.fillna(0.5)


def minmax_low(s):
    return 1 - minmax_high(s)


def safe_div(a, b):
    a = pd.to_numeric(a, errors="coerce")
    b = pd.to_numeric(b, errors="coerce")
    return np.where((np.abs(b) > 1e-12) & pd.notna(b), a / b, np.nan)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--rates-file", default="data/metabolomics/processed/exchange_rates_feed_corrected.csv")
    ap.add_argument("--clone-summary", default="results/tables/clone_decision_summary.csv")
    ap.add_argument("--pathway-debug", default="results/tables/pathway/pathway_interval_debug.csv")
    args = ap.parse_args()

    base = Path(args.base).resolve()
    outdir = base / "results" / "tables"
    outdir.mkdir(parents=True, exist_ok=True)

    rates_path = Path(args.rates_file)
    if not rates_path.is_absolute():
        rates_path = base / rates_path

    clone_path = Path(args.clone_summary)
    if not clone_path.is_absolute():
        clone_path = base / clone_path

    debug_path = Path(args.pathway_debug)
    if not debug_path.is_absolute():
        debug_path = base / debug_path

    if not rates_path.exists():
        raise FileNotFoundError(rates_path)
    if not clone_path.exists():
        raise FileNotFoundError(clone_path)

    rates = pd.read_csv(rates_path)
    rates["condition"] = clean_condition_series(rates["condition"])
    rates["rate"] = pd.to_numeric(rates["rate"], errors="coerce")

    clone = pd.read_csv(clone_path)
    clone["condition"] = clean_condition_series(clone["condition"])

    mean_rates = rates.pivot_table(index="condition", columns="metabolite", values="rate", aggfunc="mean").reset_index()
    mean_rates.columns = ["condition"] + [f"mean_rate_{c}" for c in mean_rates.columns[1:]]

    r = rates.copy()
    r["uptake_abs"] = np.where(r["rate"] < 0, -r["rate"], 0.0)
    r["secretion"] = np.where(r["rate"] > 0, r["rate"], 0.0)

    uptake = r.pivot_table(index="condition", columns="metabolite", values="uptake_abs", aggfunc="mean").reset_index()
    uptake.columns = ["condition"] + [f"uptake_abs_{c}" for c in uptake.columns[1:]]

    secre = r.pivot_table(index="condition", columns="metabolite", values="secretion", aggfunc="mean").reset_index()
    secre.columns = ["condition"] + [f"secretion_{c}" for c in secre.columns[1:]]

    final = clone.merge(mean_rates, on="condition", how="left").merge(uptake, on="condition", how="left").merge(secre, on="condition", how="left")

    for col in final.columns:
        if col not in ["condition", "recommendation"]:
            final[col] = pd.to_numeric(final[col], errors="ignore")

    required = [
        "final_titer_g_L", "mean_qP_pg_cell_day", "final_viability_pct",
        "uptake_abs_Glucose", "uptake_abs_Glutamine",
        "secretion_Lactate", "secretion_Ammonia"
    ]
    for c in required:
        if c not in final.columns:
            final[c] = np.nan

    final["lactate_per_glucose"] = safe_div(final["secretion_Lactate"], final["uptake_abs_Glucose"])
    final["ammonia_per_glutamine"] = safe_div(final["secretion_Ammonia"], final["uptake_abs_Glutamine"])
    final["titer_per_glucose_burden"] = safe_div(final["final_titer_g_L"], final["uptake_abs_Glucose"])
    final["titer_per_glutamine_burden"] = safe_div(final["final_titer_g_L"], final["uptake_abs_Glutamine"])

    final["observed_metabolic_efficiency_score"] = (
        0.30 * minmax_high(final["final_titer_g_L"])
        + 0.20 * minmax_high(final["mean_qP_pg_cell_day"])
        + 0.10 * minmax_high(final["final_viability_pct"])
        + 0.10 * minmax_low(final["lactate_per_glucose"])
        + 0.10 * minmax_low(final["ammonia_per_glutamine"])
        + 0.10 * minmax_high(final["titer_per_glucose_burden"])
        + 0.10 * minmax_high(final["titer_per_glutamine_burden"])
    ).fillna(0.0)
    final["observed_efficiency_rank"] = final["observed_metabolic_efficiency_score"].rank(ascending=False, method="min").astype(int)

    if debug_path.exists():
        dbg = pd.read_csv(debug_path)
        dbg["condition"] = clean_condition_series(dbg["condition"])
        for c in ["nonzero_model_fluxes", "active_pathway_reactions", "nonzero_exchange_fluxes", "applied_constraints"]:
            if c in dbg.columns:
                dbg[c] = pd.to_numeric(dbg[c], errors="coerce")
        cov = dbg.groupby("condition", as_index=False).agg(
            mean_nonzero_model_fluxes=("nonzero_model_fluxes", "mean"),
            mean_active_pathway_reactions=("active_pathway_reactions", "mean"),
            n_intervals_debug=("condition", "size"),
        )
        cov["pathway_coverage_ratio"] = np.where(
            cov["mean_nonzero_model_fluxes"] > 0,
            cov["mean_active_pathway_reactions"] / cov["mean_nonzero_model_fluxes"],
            np.nan
        )
        final = final.merge(cov, on="condition", how="left")
    else:
        final["mean_nonzero_model_fluxes"] = np.nan
        final["mean_active_pathway_reactions"] = np.nan
        final["pathway_coverage_ratio"] = np.nan

    def reliability(row):
        active = row.get("mean_active_pathway_reactions", np.nan)
        ratio = row.get("pathway_coverage_ratio", np.nan)
        if pd.isna(active):
            return "Pathway QC not available"
        if active < 1:
            return "Do not interpret internal pathway layer"
        if pd.notna(ratio) and ratio < 0.05:
            return "Low pathway coverage; qualitative support only"
        return "Pathway layer usable as qualitative support"

    final["pathway_interpretation_reliability"] = final.apply(reliability, axis=1)

    def bucket(row):
        t_rank = row.get("rank", np.nan)
        e_rank = row.get("observed_efficiency_rank", np.nan)
        if pd.notna(t_rank) and t_rank <= 3 and pd.notna(e_rank) and e_rank <= 3:
            return "Primary: high productivity and good observed metabolic efficiency"
        if pd.notna(t_rank) and t_rank <= 3:
            return "High productivity; check metabolic burden"
        if pd.notna(e_rank) and e_rank <= 3:
            return "Metabolically efficient; productivity may be lower"
        return "Lower priority or needs further review"

    final["interpretation_bucket"] = final.apply(bucket, axis=1)

    keep = [
        "condition", "rank", "observed_efficiency_rank", "recommendation", "interpretation_bucket",
        "decision_score_0to1", "observed_metabolic_efficiency_score",
        "final_titer_g_L", "mean_qP_pg_cell_day", "final_viability_pct",
        "uptake_abs_Glucose", "secretion_Lactate", "lactate_per_glucose",
        "uptake_abs_Glutamine", "secretion_Ammonia", "ammonia_per_glutamine",
        "titer_per_glucose_burden", "titer_per_glutamine_burden",
        "mean_nonzero_model_fluxes", "mean_active_pathway_reactions", "pathway_coverage_ratio",
        "pathway_interpretation_reliability",
    ]
    keep = [c for c in keep if c in final.columns]
    final_out = final[keep].sort_values(["observed_efficiency_rank", "rank"], na_position="last")

    out_csv = outdir / "FINAL_INTERPRETABLE_CLONE_SUMMARY.csv"
    final_out.to_csv(out_csv, index=False, encoding="utf-8-sig")
    print("[OK] saved:", out_csv)

    md = []
    md.append("# Final interpretable clone summary")
    md.append("")
    md.append("## Key interpretation")
    md.append("")
    md.append("- `clone_decision_summary.csv` is an integrated productivity + extracellular metabolic burden summary.")
    md.append("- If pathway pFBA is nonzero for only one/few clones, do not interpret zero clones as biologically lacking pathway activity.")
    md.append("- Use observed/process-derived indicators as the primary clone prioritization layer.")
    md.append("- Use FBA/pFBA mainly for feasibility and qualitative metabolic consistency unless a validated objective/pathway mapping is available.")
    md.append("")
    md.append("## Top table preview")
    md.append("")
    try:
        md.append(final_out.head(12).to_markdown(index=False))
    except Exception:
        md.append(final_out.head(12).to_string(index=False))
    md.append("")
    md.append("## Recommended wording")
    md.append("")
    md.append("> Feed-corrected extracellular exchange rates were used to constrain the iCHO3K model. The constraint-based model was used primarily for feasibility and metabolic consistency checks, while clone prioritization was based on productivity, qP, viability, and observed exchange-derived metabolic burden indicators.")
    md.append("")
    md.append("## Caution")
    md.append("")
    md.append("If most clones have zero internal pathway activity in the 16 output, do not claim that those clones lack intracellular pathway activity. It indicates the current objective/pathway mapping is not sufficiently informative for internal flux comparison.")
    report = outdir / "FINAL_INTERPRETATION_GUIDE.md"
    report.write_text("\n".join(md), encoding="utf-8")
    print("[OK] saved:", report)

    print("\n[TOP SUMMARY]")
    print(final_out.head(20).to_string(index=False))


if __name__ == "__main__":
    main()

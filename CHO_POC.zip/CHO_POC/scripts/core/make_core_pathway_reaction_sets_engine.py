
from __future__ import annotations

import argparse
import re
from pathlib import Path
import pandas as pd

CORE_PATTERNS = {
    "glycolysis": [
        r"\bHK", r"hexokinase", r"\bPFK", r"phosphofructokinase",
        r"\bFBA", r"fructose.*bisphosphate", r"\bTPI", r"triose",
        r"\bGAPD", r"glyceraldehyde", r"\bPGK", r"phosphoglycerate kinase",
        r"\bPGM", r"phosphoglycerate mutase", r"\bENO", r"enolase",
        r"\bPYK", r"pyruvate kinase",
    ],
    "tca_cycle": [
        r"\bCS", r"citrate synthase", r"\bACONT", r"aconitase",
        r"\bICDH", r"isocitrate", r"\bAKGD", r"2.oxoglutarate|alpha.?ketoglutarate",
        r"\bSUCOAS", r"succinyl", r"\bSUCD", r"succinate dehydrogenase",
        r"\bFUM", r"fumarase|fumarate", r"\bMDH", r"malate dehydrogenase",
    ],
    "lactate_pyruvate": [
        r"\bLDH", r"lactate dehydrogenase", r"\bPYR", r"pyruvate",
        r"\bEX_lac", r"lactate",
    ],
    "glutamine_glutamate": [
        r"\bGLN", r"glutamine", r"\bGLU", r"glutamate",
        r"glutaminase", r"glutamine synthetase", r"glutamate dehydrogenase",
        r"aminotransferase",
    ],
    "ammonia_nitrogen": [
        r"\bNH4", r"ammonia|ammonium", r"glutaminase",
        r"glutamate dehydrogenase", r"transaminase|aminotransferase",
    ],
    "pentose_phosphate": [
        r"\bG6PD", r"glucose.6.phosphate dehydrogenase",
        r"\bPGL", r"6.phosphoglucon", r"\bGND",
        r"\bTKT", r"transketolase", r"\bTALA", r"transaldolase",
        r"ribose|ribulose|xylulose",
    ],
    "oxidative_phosphorylation": [
        r"ATPS", r"ATP synthase", r"NADH dehydrogenase",
        r"cytochrome", r"ubiquinone", r"electron transport",
        r"complex I|complex II|complex III|complex IV",
    ],
    "amino_acid_transport": [
        r"^EX_.*(ala|arg|asn|asp|cys|gln|glu|gly|his|ile|leu|lys|met|phe|pro|ser|thr|trp|tyr|val)",
        r"transport.*(alanine|arginine|asparagine|aspartate|glutamine|glutamate|glycine|leucine|lysine|valine)",
    ],
    "biomass_product": [
        r"biomass", r"product", r"igg|antibody|mab", r"demand", r"protein",
    ],
}

DEFAULT_MAX_PER_PATHWAY = {
    "glycolysis": 25,
    "tca_cycle": 25,
    "lactate_pyruvate": 25,
    "glutamine_glutamate": 35,
    "ammonia_nitrogen": 25,
    "pentose_phosphate": 25,
    "oxidative_phosphorylation": 35,
    "amino_acid_transport": 40,
    "biomass_product": 40,
}

def combined_text(row) -> str:
    parts = []
    for c in ["reaction", "reaction_name", "matched_keywords", "reaction_string"]:
        if c in row.index:
            parts.append(str(row.get(c, "")))
    return " | ".join(parts)

def core_score(row, pathway: str):
    text = combined_text(row)
    hits = []
    for pat in CORE_PATTERNS.get(pathway, []):
        if re.search(pat, text, flags=re.I):
            hits.append(pat)
    return len(hits), "; ".join(hits)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--input", default="results/tables/pathway_reaction_sets.csv")
    ap.add_argument("--output", default="results/tables/pathway_reaction_sets_core.csv")
    ap.add_argument("--max-per-pathway", type=int, default=None)
    ap.add_argument("--keep-boundary", action="store_true")
    args = ap.parse_args()

    base = Path(args.base)
    inp = Path(args.input)
    if not inp.is_absolute():
        inp = base / inp
    out = Path(args.output)
    if not out.is_absolute():
        out = base / out

    df = pd.read_csv(inp)
    if "pathway" not in df.columns or "reaction" not in df.columns:
        raise ValueError("input must have pathway and reaction columns")

    if "include" not in df.columns:
        df["include"] = True

    rows = []
    for pathway, sub in df.groupby("pathway", sort=True):
        sub = sub.copy()
        scores = sub.apply(lambda r: core_score(r, pathway), axis=1)
        sub["core_score"] = [x[0] for x in scores]
        sub["core_hits"] = [x[1] for x in scores]
        sub = sub[sub["core_score"] > 0].copy()

        if not args.keep_boundary and "is_boundary" in sub.columns and pathway not in ["amino_acid_transport", "biomass_product"]:
            is_boundary = sub["is_boundary"].astype(str).str.lower().isin(["true", "1", "yes"])
            sub = sub[~is_boundary].copy()

        if sub.empty:
            continue

        if "keyword_score" in sub.columns:
            sub["keyword_score_num"] = pd.to_numeric(sub["keyword_score"], errors="coerce").fillna(0)
        else:
            sub["keyword_score_num"] = 0

        if "reaction_name" in sub.columns:
            sub["reaction_name_len"] = sub["reaction_name"].astype(str).str.len()
        else:
            sub["reaction_name_len"] = 999

        sub = sub.sort_values(
            ["core_score", "keyword_score_num", "reaction_name_len", "reaction"],
            ascending=[False, False, True, True],
        )

        max_n = args.max_per_pathway or DEFAULT_MAX_PER_PATHWAY.get(pathway, 30)
        sub = sub.drop_duplicates(subset=["pathway", "reaction"]).head(max_n).copy()
        sub["include"] = True
        sub["selection_note"] = f"core pathway set; max_n={max_n}; generated by 18_make_core_pathway_reaction_sets.py"
        rows.append(sub)

    core = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
    out.parent.mkdir(parents=True, exist_ok=True)
    core.to_csv(out, index=False, encoding="utf-8-sig")

    print("[OK] saved:", out)
    print("[COUNTS]")
    if core.empty:
        print("No core reactions selected. Check input file.")
    else:
        print(core.groupby("pathway")["reaction"].nunique().sort_values(ascending=False).to_string())
        print("\n[TOTAL]", core["reaction"].nunique(), "unique reactions,", len(core), "pathway rows")
        cols = [c for c in ["pathway", "reaction", "reaction_name", "core_score", "core_hits"] if c in core.columns]
        print("\nPreview:")
        print(core[cols].head(40).to_string(index=False))

if __name__ == "__main__":
    main()

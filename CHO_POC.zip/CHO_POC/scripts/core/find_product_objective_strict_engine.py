
from __future__ import annotations

import argparse
from pathlib import Path
import pandas as pd
import cobra


BAD_TERMS = [
    "oglna", "cpt", "carnitine", "palmitoyl", "acyl", "fatty acid",
    "glycosyl", "glcnac", "udp", "transport", "exchange"
]

PRODUCT_TERMS = [
    "igg", "immunoglobulin", "antibody", "mab", "monoclonal",
    "recombinant product", "recombinant protein", "secreted product",
    "product secretion"
]

BIOMASS_TERMS = ["biomass", "growth"]


def pick_model(base: Path, model_file: str | None) -> Path:
    if model_file:
        p = Path(model_file)
        return p if p.is_absolute() else base / p
    candidates = [
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.json",
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.xml",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError("Model file not found. Use --model-file")


def load_model(path: Path):
    if path.suffix.lower() == ".json":
        return cobra.io.load_json_model(str(path))
    return cobra.io.read_sbml_model(str(path))


def text_of(rxn):
    mets = " ".join([m.id + " " + (m.name or "") for m in rxn.metabolites])
    return f"{rxn.id} {rxn.name} {rxn.reaction} {mets}".lower()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--model-file", default=None)
    args = ap.parse_args()

    base = Path(args.base).resolve()
    outdir = base / "results" / "tables"
    outdir.mkdir(parents=True, exist_ok=True)

    model_path = pick_model(base, args.model_file)
    model = load_model(model_path)

    rows = []
    for rxn in model.reactions:
        t = text_of(rxn)
        rid = rxn.id

        has_product = any(k in t for k in PRODUCT_TERMS)
        has_biomass = any(k in t for k in BIOMASS_TERMS)
        bad_hits = [k for k in BAD_TERMS if k in t]

        if not has_product and not has_biomass:
            continue

        category = "product_or_IgG" if has_product else "biomass_proxy"
        score = 100 if has_product else 40
        if rid.startswith("DM_") or "demand" in t:
            score += 20
        if "secretion" in t or "secreted" in t:
            score += 20
        if bad_hits:
            score -= 200

        with model:
            try:
                model.objective = rid
                sol = model.optimize()
                status = sol.status
                val = sol.objective_value
            except Exception as e:
                status = f"error:{type(e).__name__}"
                val = None

        rows.append({
            "reaction": rid,
            "reaction_name": rxn.name,
            "category": category,
            "strict_score": score,
            "objective_test_status": status,
            "objective_test_value": val,
            "product_keyword_hit": has_product,
            "biomass_keyword_hit": has_biomass,
            "bad_hits": ";".join(bad_hits),
            "boundary": rxn.boundary,
            "lower_bound": rxn.lower_bound,
            "upper_bound": rxn.upper_bound,
            "reaction_string": rxn.reaction,
        })

    df = pd.DataFrame(rows)
    out = outdir / "product_objective_candidates_STRICT.csv"
    if df.empty:
        out.write_text("", encoding="utf-8")
        print("[WARN] No product/IgG/biomass candidates found.")
        return

    df["objective_test_value_num"] = pd.to_numeric(df["objective_test_value"], errors="coerce")
    df["nonzero_test"] = df["objective_test_value_num"].abs() > 1e-12
    cat_rank = {"product_or_IgG": 0, "biomass_proxy": 1}
    df["category_rank"] = df["category"].map(cat_rank).fillna(9)
    df = df.sort_values(["category_rank", "strict_score", "nonzero_test", "objective_test_value_num"], ascending=[True, False, False, False])
    df.to_csv(out, index=False, encoding="utf-8-sig")

    product_df = df[(df["category"] == "product_or_IgG") & (df["strict_score"] > 0)]
    rec = outdir / "RECOMMENDED_PRODUCT_OBJECTIVE_STRICT.txt"

    if product_df.empty:
        msg = [
            f"model={model_path}",
            "recommended_reaction=None",
            "",
            "No confident IgG/mAb/product secretion objective was found.",
            "Do NOT use auto-selected reactions such as C160CPT1 as product objective.",
            "Next options:",
            "1. Add a validated recombinant IgG/mAb product reaction to the model.",
            "2. Use a biomass reaction only as a proxy, not as IgG/titer objective.",
            "3. Keep FVA as feasibility/flexibility analysis, not product-specific FVA.",
        ]
    else:
        best = product_df.iloc[0]
        msg = [
            f"model={model_path}",
            f"recommended_reaction={best['reaction']}",
            f"reaction_name={best['reaction_name']}",
            f"category={best['category']}",
            f"objective_test_status={best['objective_test_status']}",
            f"objective_test_value={best['objective_test_value']}",
            "",
            "Use this only after confirming it is truly IgG/mAb/product secretion.",
        ]
    rec.write_text("\n".join(msg) + "\n", encoding="utf-8")

    print("[OK] saved:", out)
    print("[OK] saved:", rec)
    print("\n[STRICT TOP CANDIDATES]")
    cols = ["reaction", "reaction_name", "category", "strict_score", "objective_test_status", "objective_test_value", "bad_hits"]
    print(df[cols].head(30).to_string(index=False))


if __name__ == "__main__":
    main()


from __future__ import annotations

import argparse
from pathlib import Path
import math
import numpy as np
import pandas as pd
import cobra
from cobra.flux_analysis import pfba, flux_variability_analysis


IGG_RXNS = ["igg_hc", "igg_lc", "igg_formation", "DM_igg_g"]

IGG_FORMATION_SUBSTRATES = [
    "fn2m2masn_g", "fnm2masn_g", "igg_hc_r", "igg_lc_r", "ksi_pre1_g",
    "l2fn2m2masn_g", "lfn2m2masn_g", "lfnm2masn_g", "lnm2masn_g", "nm2masn_g"
]

DEFAULT_OPEN = {
    "EX_h_e": (-1000, 1000),
    "EX_h2o_e": (-1000, 1000),
    "EX_o2_e": (-1000, 1000),
    "EX_co2_e": (-1000, 1000),
    "EX_hco3_e": (-1000, 1000),
    "EX_pi_e": (-1000, 1000),
    "EX_so4_e": (-1000, 1000),
}


def clean_condition(x):
    s = str(x).strip()
    return s[:-2] if s.endswith(".0") else s


def clean_id(x):
    return str(x).strip().replace("\ufeff", "").replace("\u200b", "")


def pick_model(base: Path, model_file: str | None) -> Path:
    if model_file:
        p = Path(model_file)
        return p if p.is_absolute() else base / p
    candidates = [
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.json",
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.xml",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError("Model file not found. Use --model-file")


def load_model(path: Path):
    if path.suffix.lower() == ".json":
        return cobra.io.load_json_model(str(path))
    return cobra.io.read_sbml_model(str(path))


def finite(x):
    try:
        return math.isfinite(float(x))
    except Exception:
        return False


def apply_exchange_constraints(model, rates, condition=None, day_start=None, day_end=None, bound_buffer=0.5):
    for rid, bounds in DEFAULT_OPEN.items():
        if rid in model.reactions:
            model.reactions.get_by_id(rid).bounds = bounds

    df = rates.copy()
    df["condition"] = df["condition"].map(clean_condition)
    df["exchange_rxn"] = df["exchange_rxn"].map(clean_id)
    df["day_start"] = pd.to_numeric(df["day_start"], errors="coerce")
    df["day_end"] = pd.to_numeric(df["day_end"], errors="coerce")
    df["rate"] = pd.to_numeric(df["rate"], errors="coerce")

    if condition is None:
        first = df[["condition", "day_start", "day_end"]].dropna().drop_duplicates().iloc[0]
        condition = clean_condition(first["condition"])
        day_start = float(first["day_start"])
        day_end = float(first["day_end"])

    sub = df[(df["condition"] == clean_condition(condition)) & (df["day_start"] == float(day_start)) & (df["day_end"] == float(day_end))].copy()

    applied = []
    warnings = []
    for _, row in sub.drop_duplicates(subset=["exchange_rxn"], keep="last").iterrows():
        rid = clean_id(row["exchange_rxn"])
        if rid not in model.reactions:
            warnings.append({"reaction": rid, "issue": "missing_in_model", "metabolite": row.get("metabolite", "")})
            continue
        rate = float(row["rate"])
        if rate < 0:
            lb, ub = rate * (1 + bound_buffer), rate * (1 - bound_buffer)
        else:
            lb, ub = rate * (1 - bound_buffer), rate * (1 + bound_buffer)
        if lb > ub:
            lb, ub = ub, lb
        rxn = model.reactions.get_by_id(rid)
        rxn.bounds = (max(lb, -1000), min(ub, 1000))
        applied.append({
            "condition": condition,
            "day_start": day_start,
            "day_end": day_end,
            "reaction": rid,
            "metabolite": row.get("metabolite", ""),
            "rate": rate,
            "lower_bound": rxn.lower_bound,
            "upper_bound": rxn.upper_bound,
            "excludes_zero": not (rxn.lower_bound <= 0 <= rxn.upper_bound),
        })
    return clean_condition(condition), float(day_start), float(day_end), pd.DataFrame(applied), pd.DataFrame(warnings)


def add_sink(model, met_id, prefix="SK_DEBUG_", lb=0, ub=1000):
    if met_id not in model.metabolites:
        return None
    rxn_id = prefix + met_id
    if rxn_id in model.reactions:
        rxn = model.reactions.get_by_id(rxn_id)
        rxn.bounds = (lb, ub)
        return rxn
    met = model.metabolites.get_by_id(met_id)
    rxn = cobra.Reaction(rxn_id)
    rxn.name = f"Debug sink for {met_id}"
    rxn.lower_bound = lb
    rxn.upper_bound = ub
    # positive flux consumes metabolite
    rxn.add_metabolites({met: -1})
    model.add_reactions([rxn])
    return rxn


def add_source(model, met_id, prefix="SRC_DEBUG_", lb=0, ub=1000):
    if met_id not in model.metabolites:
        return None
    rxn_id = prefix + met_id
    if rxn_id in model.reactions:
        rxn = model.reactions.get_by_id(rxn_id)
        rxn.bounds = (lb, ub)
        return rxn
    met = model.metabolites.get_by_id(met_id)
    rxn = cobra.Reaction(rxn_id)
    rxn.name = f"Debug source for {met_id}"
    rxn.lower_bound = lb
    rxn.upper_bound = ub
    # positive flux produces metabolite
    rxn.add_metabolites({met: 1})
    model.add_reactions([rxn])
    return rxn


def test_objectives(model, label):
    rows = []
    for rid in IGG_RXNS:
        if rid not in model.reactions:
            rows.append({"scenario": label, "objective": rid, "status": "missing", "value": np.nan, "flux": np.nan})
            continue
        with model:
            model.objective = rid
            sol = model.optimize()
            rows.append({
                "scenario": label,
                "objective": rid,
                "status": sol.status,
                "value": sol.objective_value,
                "flux": sol.fluxes.get(rid, np.nan) if sol.status == "optimal" else np.nan,
            })
    return rows


def met_reaction_inventory(model):
    rows = []
    for mid in IGG_FORMATION_SUBSTRATES + ["igg_g"]:
        if mid not in model.metabolites:
            rows.append({"metabolite": mid, "status": "missing", "n_reactions": 0, "reactions": ""})
            continue
        met = model.metabolites.get_by_id(mid)
        rxn_ids = sorted([r.id for r in met.reactions])
        rows.append({
            "metabolite": mid,
            "metabolite_name": met.name,
            "status": "present",
            "n_reactions": len(rxn_ids),
            "reactions": ";".join(rxn_ids),
        })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--model-file", default=None)
    ap.add_argument("--rates-file", default="data/metabolomics/processed/exchange_rates_feed_corrected.csv")
    ap.add_argument("--condition", default="Clone08")
    ap.add_argument("--day-start", type=float, default=3.0)
    ap.add_argument("--day-end", type=float, default=5.0)
    ap.add_argument("--bound-buffer", type=float, default=0.5)
    ap.add_argument("--run-debug-fva", action="store_true")
    args = ap.parse_args()

    base = Path(args.base).resolve()
    outdir = base / "results" / "tables" / "igg_unblock_debug"
    outdir.mkdir(parents=True, exist_ok=True)

    model_path = pick_model(base, args.model_file)
    rates_path = Path(args.rates_file)
    if not rates_path.is_absolute():
        rates_path = base / rates_path

    base_model = load_model(model_path)

    inv = pd.DataFrame(met_reaction_inventory(base_model))
    inv.to_csv(outdir / "01_igg_metabolite_reaction_inventory.csv", index=False, encoding="utf-8-sig")

    # Scenario A: base model only
    rows = []
    rows += test_objectives(base_model, "A_base_model")

    # Scenario B: measured exchange constraints
    rates = pd.read_csv(rates_path)
    mB = load_model(model_path)
    cond, d0, d1, applied, warnings = apply_exchange_constraints(
        mB, rates, condition=args.condition, day_start=args.day_start, day_end=args.day_end, bound_buffer=args.bound_buffer
    )
    applied.to_csv(outdir / "02_applied_exchange_constraints.csv", index=False, encoding="utf-8-sig")
    warnings.to_csv(outdir / "03_exchange_constraint_warnings.csv", index=False, encoding="utf-8-sig")
    rows += test_objectives(mB, "B_measured_exchange_constraints")

    # Scenario C: measured constraints + glycan source only
    mC = mB.copy()
    glycan_mets = [m for m in IGG_FORMATION_SUBSTRATES if m not in ["igg_hc_r", "igg_lc_r"]]
    for mid in glycan_mets:
        add_source(mC, mid, ub=1000)
    rows += test_objectives(mC, "C_plus_glycan_sources")

    # Scenario D: measured constraints + HC/LC sources only
    mD = mB.copy()
    add_source(mD, "igg_hc_r", ub=1000)
    add_source(mD, "igg_lc_r", ub=1000)
    rows += test_objectives(mD, "D_plus_hc_lc_sources")

    # Scenario E: measured constraints + all formation substrate sources
    mE = mB.copy()
    for mid in IGG_FORMATION_SUBSTRATES:
        add_source(mE, mid, ub=1000)
    rows += test_objectives(mE, "E_plus_all_formation_substrate_sources")

    obj_df = pd.DataFrame(rows)
    obj_df.to_csv(outdir / "04_igg_objective_unblock_tests.csv", index=False, encoding="utf-8-sig")

    # Scenario F: force DM_igg_g by adding sources to all formation substrates; useful only as debugging
    if args.run_debug_fva:
        mF = mE
        mF.objective = "DM_igg_g"
        sol = mF.optimize()
        if sol.status == "optimal" and sol.objective_value and sol.objective_value > 1e-12:
            targets = [r.id for r in mF.reactions if any(k in r.id.lower() for k in ["igg", "gly", "gln", "glu", "lac", "glc", "biomass"])]
            targets = sorted(set(targets))
            try:
                fva = flux_variability_analysis(mF, reaction_list=targets, fraction_of_optimum=0.9, processes=1).reset_index().rename(columns={"index": "reaction"})
                fva["range"] = fva["maximum"] - fva["minimum"]
                fva.to_csv(outdir / "05_debug_DM_igg_g_FVA_with_artificial_sources.csv", index=False, encoding="utf-8-sig")
            except Exception as e:
                pd.DataFrame([{"issue": "debug_fva_failed", "detail": str(e)}]).to_csv(outdir / "05_debug_DM_igg_g_FVA_with_artificial_sources.csv", index=False, encoding="utf-8-sig")

    summary = []
    summary.append("IGG UNBLOCK DIAGNOSTIC SUMMARY")
    summary.append(f"model={model_path}")
    summary.append(f"rates={rates_path}")
    summary.append(f"interval={cond} {d0:g}-{d1:g}")
    summary.append("")
    summary.append("Objective test file:")
    summary.append(str(outdir / "04_igg_objective_unblock_tests.csv"))
    summary.append("")
    summary.append("Interpretation:")
    summary.append("- A_base_model: model alone.")
    summary.append("- B_measured_exchange_constraints: measured 20AA/exchange constraints applied.")
    summary.append("- C_plus_glycan_sources: tests whether glycan precursors block IgG formation.")
    summary.append("- D_plus_hc_lc_sources: tests whether heavy/light chain synthesis blocks IgG formation.")
    summary.append("- E_plus_all_formation_substrate_sources: confirms DM_igg_g demand can carry flux if all direct substrates are supplied.")
    summary.append("")
    summary.append("If B is zero but C becomes positive: glycan precursor network is the bottleneck.")
    summary.append("If B and C are zero but D becomes positive: HC/LC synthesis or amino acid/energy supply is bottleneck.")
    summary.append("If E is positive: DM_igg_g itself is not blocked; upstream supply is the issue.")
    summary.append("Artificial source scenarios are for diagnosis only and should not be used as biological product-FVA results.")
    (outdir / "00_README_IGG_UNBLOCK_DIAGNOSIS.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")

    print("\n[IGG OBJECTIVE UNBLOCK TESTS]")
    print(obj_df.to_string(index=False))
    print("\n[OK] saved:", outdir)


if __name__ == "__main__":
    main()


"""
14_make_clone_decision_summary.py v3

Fixes:
1) condition dtype mismatch during merge
2) pandas.errors.IntCastingNaNError when rank contains NaN
3) missing/NaN metric values in decision score

Run:
  cd C:\CHO_POC
  python scripts\14_make_clone_decision_summary.py --base C:\CHO_POC
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def clean_condition(df: pd.DataFrame, col: str = "condition") -> pd.DataFrame:
    if col in df.columns:
        df[col] = (
            df[col]
            .astype(str)
            .str.strip()
            .str.replace(r"\.0$", "", regex=True)
        )
    return df


def numeric_or_nan(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def minmax_good_high(s: pd.Series, neutral: float = 0.5) -> pd.Series:
    """
    Higher is better.
    NaN values are assigned neutral score so rank conversion never fails.
    """
    s = pd.to_numeric(s, errors="coerce")
    out = pd.Series([neutral] * len(s), index=s.index, dtype=float)

    valid = s.dropna()
    if valid.empty:
        return out

    lo, hi = valid.min(), valid.max()
    if pd.isna(lo) or pd.isna(hi) or hi == lo:
        return out

    out.loc[s.notna()] = (s.loc[s.notna()] - lo) / (hi - lo)
    return out.fillna(neutral)


def minmax_good_low(s: pd.Series, neutral: float = 0.5) -> pd.Series:
    return 1.0 - minmax_good_high(s, neutral=neutral)


def safe_col(df: pd.DataFrame, col: str, default=np.nan):
    if col not in df.columns:
        df[col] = default
    return df[col]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--process-csv", default="data/metabolomics/processed/converted_process_data.csv")
    ap.add_argument("--rates-csv", default="data/metabolomics/processed/exchange_rates_feed_corrected.csv")
    ap.add_argument("--batch-summary", default="results/tables/batch/batch_clone_level_summary.csv")
    args = ap.parse_args()

    base = Path(args.base)
    table_dir = base / "results" / "tables"
    fig_dir = base / "results" / "figures"
    table_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)

    process_path = Path(args.process_csv)
    if not process_path.is_absolute():
        process_path = base / process_path

    rates_path = Path(args.rates_csv)
    if not rates_path.is_absolute():
        rates_path = base / rates_path

    batch_path = Path(args.batch_summary)
    if not batch_path.is_absolute():
        batch_path = base / batch_path

    if not process_path.exists():
        raise FileNotFoundError(process_path)

    process = pd.read_csv(process_path)
    process = clean_condition(process)
    process["day"] = pd.to_numeric(process.get("day"), errors="coerce")

    process = numeric_or_nan(process, [
        "titer_g_L",
        "qP_pg_cell_day",
        "viability_pct",
        "vcd_10e6_cells_mL",
        "ivcd_10e6_cell_day_mL",
    ])

    if "condition" not in process.columns:
        raise ValueError("converted_process_data.csv must contain a 'condition' column")

    if process["condition"].isna().all() or process["day"].isna().all():
        raise ValueError("condition/day columns look empty. Check converted_process_data.csv")

    # Final day row per condition
    process_sorted = process.dropna(subset=["day"]).sort_values(["condition", "day"]).copy()
    final_idx = process_sorted.groupby("condition")["day"].idxmax()
    final = process.loc[final_idx].copy()

    final = final.rename(columns={
        "day": "final_day",
        "titer_g_L": "final_titer_g_L",
        "qP_pg_cell_day": "last_interval_qP_pg_cell_day",
        "viability_pct": "final_viability_pct",
        "vcd_10e6_cells_mL": "final_vcd_10e6_cells_mL",
        "ivcd_10e6_cell_day_mL": "final_cumulative_ivcd",
    })

    keep_cols = [
        "condition",
        "final_day",
        "final_titer_g_L",
        "last_interval_qP_pg_cell_day",
        "final_viability_pct",
        "final_vcd_10e6_cells_mL",
        "final_cumulative_ivcd",
    ]
    for c in keep_cols:
        if c not in final.columns:
            final[c] = np.nan
    final = final[keep_cols]
    final = clean_condition(final)

    qp = process.groupby("condition", as_index=False).agg(
        mean_qP_pg_cell_day=("qP_pg_cell_day", "mean"),
        max_qP_pg_cell_day=("qP_pg_cell_day", "max"),
        mean_viability_pct=("viability_pct", "mean"),
        peak_vcd_10e6_cells_mL=("vcd_10e6_cells_mL", "max"),
    )
    qp = clean_condition(qp)

    summary = final.merge(qp, on="condition", how="left")

    # Rates summary
    if rates_path.exists():
        rates = pd.read_csv(rates_path)
        rates = clean_condition(rates)
        if "rate" in rates.columns:
            rates["rate"] = pd.to_numeric(rates["rate"], errors="coerce")
        if "day_end" in rates.columns:
            rates["day_end"] = pd.to_numeric(rates["day_end"], errors="coerce")

        if {"condition", "metabolite", "rate"}.issubset(rates.columns):
            pivot_mean = rates.pivot_table(
                index="condition",
                columns="metabolite",
                values="rate",
                aggfunc="mean",
            ).reset_index()
            pivot_mean.columns = ["condition"] + [f"mean_rate_{c}" for c in pivot_mean.columns[1:]]
            pivot_mean = clean_condition(pivot_mean)
            summary = summary.merge(pivot_mean, on="condition", how="left")

        if {"condition", "metabolite", "day_end", "rate"}.issubset(rates.columns):
            late = (
                rates.dropna(subset=["day_end"])
                .sort_values(["condition", "metabolite", "day_end"])
                .groupby(["condition", "metabolite"], as_index=False)
                .tail(1)
            )
            if not late.empty:
                late_pivot = late.pivot_table(
                    index="condition",
                    columns="metabolite",
                    values="rate",
                    aggfunc="mean",
                ).reset_index()
                late_pivot.columns = ["condition"] + [f"late_rate_{c}" for c in late_pivot.columns[1:]]
                late_pivot = clean_condition(late_pivot)
                summary = summary.merge(late_pivot, on="condition", how="left")
    else:
        print("[WARN] rates csv not found:", rates_path)

    # Batch FBA summary
    if batch_path.exists():
        batch = pd.read_csv(batch_path)
        batch = clean_condition(batch)
        summary = summary.merge(batch, on="condition", how="left", suffixes=("", "_batch"))
    else:
        print("[WARN] batch summary not found:", batch_path)

    # Numeric conversion
    for col in summary.columns:
        if col not in ["condition", "recommendation", "fba_status", "pfba_status", "mode", "tag", "interval"]:
            summary[col] = pd.to_numeric(summary[col], errors="coerce")

    score = pd.Series(0.0, index=summary.index, dtype=float)
    total_weight = 0.0

    def add_score(col_name: str, weight: float, direction="high"):
        nonlocal score, total_weight
        if col_name not in summary.columns:
            print(f"[WARN] score metric missing: {col_name}")
            return
        if direction == "high":
            metric_score = minmax_good_high(summary[col_name])
        else:
            metric_score = minmax_good_low(summary[col_name])
        score[:] = score + weight * metric_score
        total_weight += weight

    add_score("final_titer_g_L", 0.35, "high")
    add_score("mean_qP_pg_cell_day", 0.20, "high")
    add_score("final_viability_pct", 0.15, "high")
    add_score("mean_rate_Lactate", 0.10, "low")
    add_score("mean_rate_Ammonia", 0.10, "low")

    if "mean_rate_Glucose" in summary.columns:
        summary["mean_rate_Glucose_abs"] = pd.to_numeric(summary["mean_rate_Glucose"], errors="coerce").abs()
        add_score("mean_rate_Glucose_abs", 0.10, "low")
    else:
        print("[WARN] score metric missing: mean_rate_Glucose")

    if total_weight > 0:
        summary["decision_score_0to1"] = (score / total_weight).replace([np.inf, -np.inf], np.nan).fillna(0.0)
    else:
        summary["decision_score_0to1"] = 0.0

    # This prevents IntCastingNaNError
    rank_series = summary["decision_score_0to1"].rank(ascending=False, method="min")
    summary["rank"] = rank_series.fillna(len(summary) + 1).astype(int)

    def label(row):
        if row["rank"] <= 3:
            return "Top candidate"
        if row["rank"] <= 6:
            return "Middle candidate"
        return "Lower candidate"

    summary["recommendation"] = summary.apply(label, axis=1)
    summary = summary.sort_values(["rank", "condition"]).reset_index(drop=True)

    out = table_dir / "clone_decision_summary.csv"
    summary.to_csv(out, index=False, encoding="utf-8-sig")
    print("[OK] saved:", out)

    # Score plot
    try:
        fig, ax = plt.subplots(figsize=(10, 5.5))
        plot_df = summary.sort_values("decision_score_0to1", ascending=True)
        ax.barh(plot_df["condition"], plot_df["decision_score_0to1"])
        ax.set_xlabel("Decision score, 0-1")
        ax.set_title("Clone decision score: titer/qP/viability/metabolic burden")
        ax.grid(axis="x", linestyle=":", alpha=0.5)
        fig.tight_layout()
        p = fig_dir / "clone_decision_score.png"
        fig.savefig(p, dpi=300)
        print("[OK] saved:", p)
    except Exception as e:
        print("[WARN] score plot failed:", e)

    # Final titer vs lactate
    if "mean_rate_Lactate" in summary.columns and "final_titer_g_L" in summary.columns:
        try:
            plot_df = summary.dropna(subset=["mean_rate_Lactate", "final_titer_g_L"]).copy()
            if not plot_df.empty:
                fig, ax = plt.subplots(figsize=(7, 5.5))
                ax.scatter(plot_df["mean_rate_Lactate"], plot_df["final_titer_g_L"])
                for _, r in plot_df.iterrows():
                    ax.text(r["mean_rate_Lactate"], r["final_titer_g_L"], str(r["condition"]), fontsize=8, ha="left", va="bottom")
                ax.set_xlabel("Mean feed-corrected lactate exchange rate")
                ax.set_ylabel("Final titer, g/L")
                ax.set_title("Final titer vs lactate burden")
                ax.grid(True, linestyle=":", alpha=0.5)
                fig.tight_layout()
                p = fig_dir / "final_titer_vs_lactate.png"
                fig.savefig(p, dpi=300)
                print("[OK] saved:", p)
        except Exception as e:
            print("[WARN] final_titer_vs_lactate plot failed:", e)

    cols_show = [
        "rank",
        "condition",
        "recommendation",
        "decision_score_0to1",
        "final_titer_g_L",
        "mean_qP_pg_cell_day",
        "final_viability_pct",
        "mean_rate_Glucose",
        "mean_rate_Lactate",
        "mean_rate_Glutamine",
        "mean_rate_Ammonia",
    ]
    cols_show = [c for c in cols_show if c in summary.columns]

    print("\n[DECISION SUMMARY]")
    print(summary[cols_show].to_string(index=False))

    # Helpful QC for missing values
    qc_cols = ["final_titer_g_L", "mean_qP_pg_cell_day", "final_viability_pct", "mean_rate_Glucose", "mean_rate_Lactate", "mean_rate_Ammonia"]
    qc_cols = [c for c in qc_cols if c in summary.columns]
    if qc_cols:
        missing = summary[["condition"] + qc_cols].isna().sum()
        print("\n[MISSING VALUE QC]")
        print(missing.to_string())


if __name__ == "__main__":
    main()

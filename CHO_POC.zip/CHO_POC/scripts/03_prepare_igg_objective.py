from __future__ import annotations

import argparse
import sys
from pathlib import Path
import pandas as pd
from _common import run_cmd, make_log, core_script, exchange_rates_file, top_conditions


def main():
    ap = argparse.ArgumentParser(description="Stage 3: model scout, core pathway set, strict IgG objective check/unblock diagnostic.")
    ap.add_argument("--base", default=".")
    ap.add_argument("--condition", default="auto", help="auto or clone ID for IgG unblock diagnostic.")
    ap.add_argument("--day-start", type=float, default=3.0)
    ap.add_argument("--day-end", type=float, default=5.0)
    ap.add_argument("--bound-buffer", type=float, default=0.5)
    args = ap.parse_args()

    base = Path(args.base).resolve()
    log = make_log(base, "03_prepare_igg_objective")
    rates = exchange_rates_file(base)

    run_cmd([sys.executable, str(core_script(base, "model_pathway_scout_engine.py")), "--base", str(base)], log, required=True)

    run_cmd([sys.executable, str(core_script(base, "make_core_pathway_reaction_sets_engine.py")), "--base", str(base)], log, required=True)

    run_cmd([sys.executable, str(core_script(base, "find_product_objective_strict_engine.py")), "--base", str(base)], log, required=True)

    cond = args.condition
    if cond == "auto":
        cond = top_conditions(base, top_n=1)[0]

    run_cmd([
        sys.executable, str(core_script(base, "diagnose_igg_unblock_engine.py")),
        "--base", str(base),
        "--rates-file", str(rates),
        "--condition", cond,
        "--day-start", str(args.day_start),
        "--day-end", str(args.day_end),
        "--bound-buffer", str(args.bound_buffer),
    ], log, required=False)

    print("[OK] Stage 3 complete.")
    print("Core pathway set:", base / "results" / "tables" / "pathway_reaction_sets_core.csv")
    print("Objective candidates:", base / "results" / "tables" / "product_objective_candidates_STRICT.csv")
    print("IgG unblock test:", base / "results" / "tables" / "igg_unblock_debug" / "04_igg_objective_unblock_tests.csv")


if __name__ == "__main__":
    main()

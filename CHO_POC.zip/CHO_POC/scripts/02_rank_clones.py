from __future__ import annotations

import argparse
import sys
from pathlib import Path
from _common import run_cmd, make_log, core_script, exchange_rates_file


def main():
    ap = argparse.ArgumentParser(description="Stage 2: batch feasibility/pFBA + clone ranking.")
    ap.add_argument("--base", default=".")
    ap.add_argument("--mode", default="strict_then_relaxed", choices=["strict", "relaxed", "strict_then_relaxed"])
    args = ap.parse_args()

    base = Path(args.base).resolve()
    log = make_log(base, "02_rank_clones")
    rates = exchange_rates_file(base)

    run_cmd([
        sys.executable, str(core_script(base, "batch_run_intervals_engine.py")),
        "--base", str(base),
        "--rates-file", str(rates),
        "--mode", args.mode,
        "--fva-mode", "none",
    ], log, required=True)

    # Optional plot; does not stop pipeline if unavailable
    if core_script(base, "plot_batch_results_engine.py").exists():
        run_cmd([
            sys.executable, str(core_script(base, "plot_batch_results_engine.py")),
            "--base", str(base),
        ], log, required=False)

    run_cmd([
        sys.executable, str(core_script(base, "clone_decision_summary_engine.py")),
        "--base", str(base),
    ], log, required=True)

    print("[OK] Stage 2 complete:", base / "results" / "tables" / "clone_decision_summary.csv")


if __name__ == "__main__":
    main()

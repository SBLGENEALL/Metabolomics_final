from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from datetime import datetime
import pandas as pd


def ensure_dirs(base: Path):
    for d in [
        "data/metabolomics/raw", "data/metabolomics/processed",
        "results/tables", "results/figures", "logs", "model", "docs"
    ]:
        (base / d).mkdir(parents=True, exist_ok=True)


def make_log(base: Path, name: str) -> Path:
    logs = base / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    return logs / f"{name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"


def run_cmd(cmd: list[str], log_file: Path, required: bool = True) -> int:
    line = " ".join([f'"{x}"' if " " in str(x) else str(x) for x in cmd])
    print("\n" + "=" * 90)
    print("[RUN]", line)
    print("=" * 90)
    p = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    print(p.stdout)
    with open(log_file, "a", encoding="utf-8") as f:
        f.write("\n" + "=" * 90 + "\n")
        f.write("[RUN] " + line + "\n")
        f.write("=" * 90 + "\n")
        f.write(p.stdout)
    if p.returncode != 0 and required:
        raise RuntimeError(f"Command failed: {line}")
    return p.returncode


def core_script(base: Path, filename: str) -> Path:
    p = base / "scripts" / "core" / filename
    if not p.exists():
        raise FileNotFoundError(f"Missing core script: {p}")
    return p


def pick_raw_excel(base: Path, raw_excel: str | None = None) -> Path:
    if raw_excel:
        p = Path(raw_excel)
        return p if p.is_absolute() else base / p
    raw_dir = base / "data" / "metabolomics" / "raw"
    candidates = [
        raw_dir / "CHO_raw_data.xlsx",
        raw_dir / "CHO_raw_data_practice_20AA.xlsx",
    ]
    for p in candidates:
        if p.exists():
            return p
    xs = sorted(raw_dir.glob("*.xlsx"))
    if xs:
        return xs[0]
    raise FileNotFoundError(f"No raw Excel file found in {raw_dir}")


def exchange_rates_file(base: Path) -> Path:
    p = base / "data" / "metabolomics" / "processed" / "exchange_rates_feed_corrected.csv"
    if not p.exists():
        raise FileNotFoundError(f"Exchange rates file not found: {p}")
    return p


def top_conditions(base: Path, top_n: int = 3) -> list[str]:
    p = base / "results" / "tables" / "clone_decision_summary.csv"
    if not p.exists():
        raise FileNotFoundError(f"clone_decision_summary.csv not found: {p}")
    df = pd.read_csv(p)
    df["condition"] = df["condition"].astype(str)
    if "rank" in df.columns:
        df = df.sort_values("rank")
    elif "decision_score_0to1" in df.columns:
        df = df.sort_values("decision_score_0to1", ascending=False)
    return df["condition"].head(top_n).tolist()

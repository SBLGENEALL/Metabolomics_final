from __future__ import annotations

import argparse
import sys
from pathlib import Path
from _common import run_cmd, make_log, core_script, exchange_rates_file, top_conditions


def main():
    ap = argparse.ArgumentParser(description="Stage 4: DM_igg_g targeted product FVA for selected/top clones + bound-driven filtering.")
    ap.add_argument("--base", default=".")
    ap.add_argument("--conditions", nargs="*", default=None)
    ap.add_argument("--top-n", type=int, default=3)
    ap.add_argument("--objective", default="DM_igg_g")
    ap.add_argument("--fraction", type=float, default=0.9)
    ap.add_argument("--bound-buffer", type=float, default=0.5)
    ap.add_argument("--processes", type=int, default=1)
    ap.add_argument("--filter-max-range", type=float, default=500.0)
    ap.add_argument("--filter-max-absolute-bound", type=float, default=900.0)
    args = ap.parse_args()

    base = Path(args.base).resolve()
    log = make_log(base, "04_run_igg_product_fva")
    rates = exchange_rates_file(base)
    pathway = base / "results" / "tables" / "pathway_reaction_sets_core.csv"
    if not pathway.exists():
        raise FileNotFoundError(f"Core pathway file not found. Run Stage 3 first: {pathway}")

    conditions = args.conditions if args.conditions else top_conditions(base, top_n=args.top_n)

    run_cmd([
        sys.executable, str(core_script(base, "run_targeted_product_fva_engine.py")),
        "--base", str(base),
        "--rates-file", str(rates),
        "--pathway-file", str(pathway),
        "--conditions", *conditions,
        "--objective", args.objective,
        "--fraction", str(args.fraction),
        "--bound-buffer", str(args.bound_buffer),
        "--processes", str(args.processes),
    ], log, required=True)

    run_cmd([
        sys.executable, str(core_script(base, "filter_targeted_product_fva_engine.py")),
        "--base", str(base),
        "--max-range", str(args.filter_max_range),
        "--max-absolute-bound", str(args.filter_max_absolute_bound),
    ], log, required=True)

    print("[OK] Stage 4 complete.")
    print("Raw targeted FVA:", base / "results" / "tables" / "targeted_product_fva" / "targeted_product_fva_clone_summary.csv")
    print("Filtered targeted FVA:", base / "results" / "tables" / "targeted_product_fva" / "targeted_product_fva_clone_summary_FILTERED.csv")


if __name__ == "__main__":
    main()
